// Licensed under the Apache License, Version 2.0.
// Copyright 2026 Julien Bombled

namespace ConfluenceRAGBuilder.ConsoleHost;

internal sealed class ConversionJob
{
    public int SchemaVersion { get; set; }

    public List<PageJob> Pages { get; set; } = [];
}

internal sealed class PageJob
{
    public string PageId { get; set; } = string.Empty;

    public string Title { get; set; } = string.Empty;

    public string SpaceKey { get; set; } = string.Empty;

    public int Version { get; set; }

    public string UpdatedAt { get; set; } = string.Empty;

    public string Author { get; set; } = string.Empty;

    public string CanonicalUrl { get; set; } = string.Empty;

    public string XhtmlPath { get; set; } = string.Empty;

    public List<AttachmentJob> Attachments { get; set; } = [];
}

internal sealed class AttachmentJob
{
    public string AttachmentId { get; set; } = string.Empty;

    public string FileName { get; set; } = string.Empty;

    public string MediaType { get; set; } = string.Empty;

    public string Path { get; set; } = string.Empty;

    public bool IsDrawioSource { get; set; }
}

internal sealed class ConversionReport
{
    public int SchemaVersion { get; set; }

    public string ToolVersion { get; set; } = string.Empty;

    public List<PageConversionReport> Pages { get; set; } = [];
}

internal sealed class PageConversionReport
{
    public string PageId { get; set; } = string.Empty;

    public string Status { get; set; } = string.Empty;

    public List<string>? MarkdownPaths { get; set; }

    public string? ErrorCode { get; set; }
}
