// Licensed under the Apache License, Version 2.0.
// Copyright 2026 Julien Bombled

namespace ConfluenceRAGBuilder.ConsoleHost;

internal static class Program
{
    private static async Task<int> Main(string[] args)
    {
        return await ConversionApplication.RunAsync(args, CancellationToken.None);
    }
}
