// Licensed under the Apache License, Version 2.0.
// Copyright 2026 Julien Bombled

using System.Reflection;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using ConfluenceRAGBuilder.Helpers;
using ConfluenceRAGBuilder.Models;
using ConfluenceRAGBuilder.Services.Conversion;
using ConfluenceRAGBuilder.Services.Export;

namespace ConfluenceRAGBuilder.ConsoleHost;

internal static class ConversionApplication
{
    internal const int SuccessExitCode = 0;
    internal const int GlobalFailureExitCode = 1;
    internal const int PartialFailureExitCode = 2;
    internal const string ProbeArgument = "--probe";
    internal const string VersionArgument = "--version";

    private const string JobFileName = "job.json";
    private const string ResultFileName = "result.json";
    private const string MarkdownDirectoryName = "markdown";
    private const string AttachmentsDirectoryName = "_attachments";
    private const string ConvertedStatus = "converted";
    private const string FailedStatus = "failed";

    private static readonly UTF8Encoding StrictUtf8 = new(false, true);
    private static readonly JsonSerializerOptions SerializerOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.SnakeCaseLower,
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
        RespectNullableAnnotations = true,
        UnmappedMemberHandling = JsonUnmappedMemberHandling.Disallow,
        WriteIndented = true
    };

    internal static async Task<int> RunAsync(string[] args, CancellationToken cancellationToken)
    {
        if (args is [ProbeArgument])
        {
            System.Console.Out.WriteLine(JsonSerializer.Serialize(
                new CapabilityProbe(GetToolVersion(), JobValidator.SupportedSchemaVersion),
                SerializerOptions));
            return SuccessExitCode;
        }

        if (args is [VersionArgument])
        {
            System.Console.Out.WriteLine(GetToolVersion());
            return SuccessExitCode;
        }

        if (args.Length != 1)
        {
            System.Console.Error.WriteLine(
                "Usage: ConfluenceRAGBuilder.Console <working-directory> | --probe | --version");
            return GlobalFailureExitCode;
        }

        try
        {
            string workingDirectory = Path.GetFullPath(args[0]);
            string jobPath = Path.Combine(workingDirectory, JobFileName);
            ConversionJob? job = await ReadAndValidateJobAsync(jobPath, cancellationToken);
            if (job is null)
            {
                return GlobalFailureExitCode;
            }

            ConversionReport report = await ConvertJobAsync(workingDirectory, job, cancellationToken);
            await WriteJsonAsync(Path.Combine(workingDirectory, ResultFileName), report, cancellationToken);

            return report.Pages.Any(page => page.Status == FailedStatus)
                ? PartialFailureExitCode
                : SuccessExitCode;
        }
        catch (Exception exception) when (exception is IOException
            or UnauthorizedAccessException
            or JsonException
            or NotSupportedException
            or ArgumentException)
        {
            System.Console.Error.WriteLine($"Global conversion failure: {exception.Message}");
            return GlobalFailureExitCode;
        }
    }

    private static async Task<ConversionJob?> ReadAndValidateJobAsync(
        string jobPath,
        CancellationToken cancellationToken)
    {
        if (!File.Exists(jobPath))
        {
            System.Console.Error.WriteLine("Invalid job: job_not_found");
            return null;
        }

        FileInfo jobFile = new(jobPath);
        if (jobFile.Length > JobValidator.MaximumJobBytes)
        {
            System.Console.Error.WriteLine("Invalid job: job_too_large");
            return null;
        }

        string json = await File.ReadAllTextAsync(jobPath, StrictUtf8, cancellationToken);
        ConversionJob? job;
        try
        {
            job = JsonSerializer.Deserialize<ConversionJob>(json, SerializerOptions);
        }
        catch (JsonException exception)
        {
            System.Console.Error.WriteLine($"Invalid job: json_invalid ({exception.Message})");
            return null;
        }

        if (!JobValidator.TryValidate(job, out string errorCode))
        {
            System.Console.Error.WriteLine($"Invalid job: {errorCode}");
            return null;
        }

        return job;
    }

    private static async Task<ConversionReport> ConvertJobAsync(
        string workingDirectory,
        ConversionJob job,
        CancellationToken cancellationToken)
    {
        ConversionReport report = new()
        {
            SchemaVersion = JobValidator.SupportedSchemaVersion,
            ToolVersion = GetToolVersion()
        };

        IHtmlToMarkdownConverter converter = new HtmlToMarkdownConverter();
        ISmartSplitterService splitter = new SmartSplitterService();

        foreach (PageJob page in job.Pages)
        {
            PageConversionReport pageReport = await ConvertPageAsync(
                workingDirectory,
                page,
                converter,
                splitter,
                cancellationToken);
            report.Pages.Add(pageReport);
        }

        return report;
    }

    private static async Task<PageConversionReport> ConvertPageAsync(
        string workingDirectory,
        PageJob page,
        IHtmlToMarkdownConverter converter,
        ISmartSplitterService splitter,
        CancellationToken cancellationToken)
    {
        try
        {
            string xhtmlPath = ResolveContainedPath(workingDirectory, page.XhtmlPath);
            if (!File.Exists(xhtmlPath))
            {
                return Failed(page.PageId, "xhtml_not_found");
            }

            if (new FileInfo(xhtmlPath).Length > JobValidator.MaximumXhtmlBytes)
            {
                return Failed(page.PageId, "xhtml_too_large");
            }

            foreach (AttachmentJob attachment in page.Attachments)
            {
                string sourcePath = ResolveContainedPath(workingDirectory, attachment.Path);
                if (!File.Exists(sourcePath))
                {
                    return Failed(page.PageId, "attachment_not_found");
                }

                if (new FileInfo(sourcePath).Length > JobValidator.MaximumAttachmentBytes)
                {
                    return Failed(page.PageId, "attachment_too_large");
                }
            }

            if (!TryResolveAttachmentOutputNames(page.Attachments, out var outputNames))
            {
                return Failed(page.PageId, "attachment_output_name_collision");
            }

            string html = await File.ReadAllTextAsync(xhtmlPath, StrictUtf8, cancellationToken);
            List<AttachmentInfo> attachments = await CopyAttachmentsAsync(
                workingDirectory,
                page,
                outputNames,
                cancellationToken);

            ConversionContext context = new()
            {
                PageId = page.PageId,
                PageTitle = page.Title,
                SpaceKey = page.SpaceKey,
                Attachments = attachments,
                AttachmentsRelativePath = $"../{AttachmentsDirectoryName}/{page.PageId}/"
            };

            ConversionResult conversion = converter.Convert(html, context);
            SplitResult split = splitter.Split(
                conversion.Markdown,
                page.PageId,
                page.Title,
                new SplitOptions());

            List<string> markdownPaths = await WriteMarkdownPartsAsync(
                workingDirectory,
                split.Parts,
                cancellationToken);

            return new PageConversionReport
            {
                PageId = page.PageId,
                Status = ConvertedStatus,
                MarkdownPaths = markdownPaths
            };
        }
        catch (Exception exception) when (exception is not OperationCanceledException)
        {
            System.Console.Error.WriteLine($"Page {page.PageId} failed: {exception.Message}");
            return Failed(page.PageId, "conversion_failed");
        }
    }

    private static async Task<List<AttachmentInfo>> CopyAttachmentsAsync(
        string workingDirectory,
        PageJob page,
        IReadOnlyDictionary<AttachmentJob, string> outputNames,
        CancellationToken cancellationToken)
    {
        List<AttachmentInfo> attachments = [];
        if (page.Attachments.Count == 0)
        {
            return attachments;
        }

        string targetDirectory = Path.Combine(workingDirectory, AttachmentsDirectoryName, page.PageId);
        Directory.CreateDirectory(targetDirectory);

        foreach (AttachmentJob attachmentJob in page.Attachments)
        {
            string sourcePath = ResolveContainedPath(workingDirectory, attachmentJob.Path);
            string outputFileName = outputNames[attachmentJob];
            string targetPath = Path.Combine(targetDirectory, outputFileName);
            await CopyFileAsync(sourcePath, targetPath, cancellationToken);

            AttachmentInfo attachment = new()
            {
                Id = attachmentJob.AttachmentId,
                FileName = attachmentJob.FileName,
                OutputFileName = outputFileName,
                MediaType = attachmentJob.MediaType,
                FileSize = new FileInfo(sourcePath).Length,
                LocalPath = targetPath,
                IsDrawIoSourceCandidate = attachmentJob.IsDrawioSource,
                PageId = page.PageId,
                Downloaded = true
            };
            attachments.Add(attachment);

            string? drawIoTextPath = await DrawIoTextExporter.ExportReadableMarkdownAsync(
                attachment,
                cancellationToken);
            if (drawIoTextPath is not null)
            {
                string content = await File.ReadAllTextAsync(drawIoTextPath, StrictUtf8, cancellationToken);
                await WriteTextAsync(drawIoTextPath, content, cancellationToken);
            }
        }

        return attachments;
    }

    internal static bool TryResolveAttachmentOutputNames(
        IReadOnlyList<AttachmentJob> attachments,
        out IReadOnlyDictionary<AttachmentJob, string> outputNames)
    {
        var candidates = attachments
            .Select(attachment => new AttachmentOutputName(
                attachment,
                FileNameHelper.ToSafeFileName(attachment.FileName)))
            .ToList();
        var collidingNames = candidates
            .GroupBy(candidate => candidate.SafeFileName, StringComparer.OrdinalIgnoreCase)
            .Where(group => group.Count() > 1)
            .Select(group => group.Key)
            .ToHashSet(StringComparer.OrdinalIgnoreCase);

        Dictionary<AttachmentJob, string> resolvedNames = [];
        HashSet<string> uniqueNames = new(StringComparer.OrdinalIgnoreCase);
        foreach (AttachmentOutputName candidate in candidates)
        {
            bool requiresSuffix = !candidate.Attachment.FileName.Equals(
                    candidate.SafeFileName,
                    StringComparison.Ordinal)
                || collidingNames.Contains(candidate.SafeFileName);
            string resolvedName = candidate.SafeFileName;
            if (requiresSuffix
                && !FileNameHelper.TryAddSuffixBeforeExtension(
                    candidate.SafeFileName,
                    $"-{candidate.Attachment.AttachmentId}",
                    out resolvedName))
            {
                outputNames = new Dictionary<AttachmentJob, string>();
                return false;
            }

            if (!FileNameHelper.IsWindowsSafeFileName(resolvedName)
                || !uniqueNames.Add(resolvedName))
            {
                outputNames = new Dictionary<AttachmentJob, string>();
                return false;
            }

            resolvedNames.Add(candidate.Attachment, resolvedName);
        }

        outputNames = resolvedNames;
        return true;
    }

    private static async Task<List<string>> WriteMarkdownPartsAsync(
        string workingDirectory,
        IReadOnlyList<SplitPart> parts,
        CancellationToken cancellationToken)
    {
        string markdownDirectory = Path.Combine(workingDirectory, MarkdownDirectoryName);
        Directory.CreateDirectory(markdownDirectory);

        List<string> paths = [];
        foreach (SplitPart part in parts)
        {
            string outputPath = Path.Combine(markdownDirectory, part.FileName);
            await WriteTextAsync(outputPath, part.Content, cancellationToken);
            paths.Add(ToContractPath(Path.GetRelativePath(workingDirectory, outputPath)));
        }

        return paths;
    }

    private static async Task CopyFileAsync(
        string sourcePath,
        string targetPath,
        CancellationToken cancellationToken)
    {
        await using FileStream source = new(
            sourcePath,
            FileMode.Open,
            FileAccess.Read,
            FileShare.Read,
            81920,
            FileOptions.Asynchronous | FileOptions.SequentialScan);
        await using FileStream target = new(
            targetPath,
            FileMode.Create,
            FileAccess.Write,
            FileShare.None,
            81920,
            FileOptions.Asynchronous);
        await source.CopyToAsync(target, cancellationToken);
    }

    private static async Task WriteJsonAsync<T>(
        string path,
        T value,
        CancellationToken cancellationToken)
    {
        string json = JsonSerializer.Serialize(value, SerializerOptions);
        await WriteTextAsync(path, json, cancellationToken);
    }

    private static async Task WriteTextAsync(
        string path,
        string content,
        CancellationToken cancellationToken)
    {
        string normalized = content.Replace("\r\n", "\n", StringComparison.Ordinal)
            .Replace('\r', '\n')
            .TrimEnd('\n') + "\n";
        byte[] bytes = StrictUtf8.GetBytes(normalized);
        await File.WriteAllBytesAsync(path, bytes, cancellationToken);
    }

    private static string ResolveContainedPath(string workingDirectory, string relativePath)
    {
        string normalizedRelativePath = relativePath.Replace('/', Path.DirectorySeparatorChar);
        string fullPath = Path.GetFullPath(normalizedRelativePath, workingDirectory);
        string relativeCheck = Path.GetRelativePath(workingDirectory, fullPath);
        if (Path.IsPathRooted(relativeCheck)
            || relativeCheck == ".."
            || relativeCheck.StartsWith($"..{Path.DirectorySeparatorChar}", StringComparison.Ordinal))
        {
            throw new ArgumentException("The path escapes the working directory.", nameof(relativePath));
        }

        return fullPath;
    }

    private static PageConversionReport Failed(string pageId, string errorCode)
    {
        return new PageConversionReport
        {
            PageId = pageId,
            Status = FailedStatus,
            ErrorCode = errorCode
        };
    }

    private static string ToContractPath(string path)
    {
        return path.Replace(Path.DirectorySeparatorChar, '/');
    }

    private static string GetToolVersion()
    {
        Version? version = Assembly.GetExecutingAssembly().GetName().Version;
        return version is null ? "0.0.0" : $"{version.Major}.{version.Minor}.{version.Build}";
    }

    private sealed record AttachmentOutputName(AttachmentJob Attachment, string SafeFileName);

    private sealed record CapabilityProbe(
        string ToolVersion,
        int SchemaVersion);
}
