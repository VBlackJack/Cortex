// Licensed under the Apache License, Version 2.0.
// Copyright 2026 Julien Bombled

using System.Globalization;
using System.Text.RegularExpressions;

namespace ConfluenceRAGBuilder.ConsoleHost;

internal static partial class JobValidator
{
    internal const int SupportedSchemaVersion = 1;
    internal const int MaximumPageCount = 1000;
    internal const int MaximumAttachmentsPerPage = 1000;
    internal const long MaximumJobBytes = 8 * 1024 * 1024;
    internal const long MaximumXhtmlBytes = 64 * 1024 * 1024;
    internal const long MaximumAttachmentBytes = 256 * 1024 * 1024;

    internal static bool TryValidate(ConversionJob? job, out string errorCode)
    {
        if (job is null)
        {
            errorCode = "job_invalid";
            return false;
        }

        if (job.SchemaVersion != SupportedSchemaVersion)
        {
            errorCode = "schema_version_unsupported";
            return false;
        }

        if (job.Pages.Count is < 1 or > MaximumPageCount)
        {
            errorCode = "page_count_invalid";
            return false;
        }

        HashSet<string> pageIds = new(StringComparer.Ordinal);
        foreach (PageJob page in job.Pages)
        {
            if (!TryValidatePage(page, pageIds, out errorCode))
            {
                return false;
            }
        }

        errorCode = string.Empty;
        return true;
    }

    internal static bool IsSafeRelativePath(string path)
    {
        if (string.IsNullOrWhiteSpace(path)
            || path.Length > 1024
            || DriveRelativePathPattern().IsMatch(path)
            || Path.IsPathRooted(path)
            || Path.IsPathFullyQualified(path))
        {
            return false;
        }

        string[] segments = path.Split(['/', '\\'], StringSplitOptions.None);
        return segments.All(segment => segment != "..");
    }

    private static bool TryValidatePage(PageJob page, HashSet<string> pageIds, out string errorCode)
    {
        if (!PageIdPattern().IsMatch(page.PageId)
            || !pageIds.Add(page.PageId))
        {
            errorCode = pageIds.Contains(page.PageId) ? "page_id_duplicate" : "page_id_invalid";
            return false;
        }

        if (!HasLength(page.Title, 1, 512)
            || !HasLength(page.SpaceKey, 1, 64)
            || page.Version < 1
            || !HasLength(page.Author, 1, 256)
            || !IsValidTimestamp(page.UpdatedAt)
            || !IsValidCanonicalUrl(page.CanonicalUrl)
            || !IsSafeRelativePath(page.XhtmlPath)
            || page.Attachments.Count > MaximumAttachmentsPerPage)
        {
            errorCode = "page_invalid";
            return false;
        }

        foreach (AttachmentJob attachment in page.Attachments)
        {
            if (!HasLength(attachment.AttachmentId, 1, 128)
                || !IsSafeFileName(attachment.FileName)
                || !HasLength(attachment.MediaType, 1, 255)
                || !IsSafeRelativePath(attachment.Path))
            {
                errorCode = "attachment_invalid";
                return false;
            }
        }

        errorCode = string.Empty;
        return true;
    }

    private static bool HasLength(string value, int minimum, int maximum)
    {
        return value.Length >= minimum && value.Length <= maximum;
    }

    private static bool IsSafeFileName(string fileName)
    {
        return HasLength(fileName, 1, 255)
            && fileName is not "." and not ".."
            && fileName.IndexOfAny(['/', '\\']) < 0;
    }

    private static bool IsValidTimestamp(string value)
    {
        return TimestampPattern().IsMatch(value)
            && DateTimeOffset.TryParse(
                value,
                CultureInfo.InvariantCulture,
                DateTimeStyles.RoundtripKind,
                out _);
    }

    private static bool IsValidCanonicalUrl(string value)
    {
        return value.Length <= 2048
            && Uri.TryCreate(value, UriKind.Absolute, out Uri? uri)
            && (uri.Scheme == Uri.UriSchemeHttp || uri.Scheme == Uri.UriSchemeHttps);
    }

    [GeneratedRegex("^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$", RegexOptions.CultureInvariant)]
    private static partial Regex PageIdPattern();

    [GeneratedRegex("^[A-Za-z]:", RegexOptions.CultureInvariant)]
    private static partial Regex DriveRelativePathPattern();

    [GeneratedRegex("^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(?:\\.[0-9]+)?(?:Z|[+-][0-9]{2}:[0-9]{2})$", RegexOptions.CultureInvariant)]
    private static partial Regex TimestampPattern();
}
