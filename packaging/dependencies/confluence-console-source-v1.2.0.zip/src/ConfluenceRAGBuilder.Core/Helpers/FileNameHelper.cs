using System.Collections.Generic;
using System.Linq;
using ConfluenceRAGBuilder.Models;

namespace ConfluenceRAGBuilder.Helpers;

/// <summary>
/// Produces file names that are safe on Windows.
/// </summary>
public static class FileNameHelper
{
    /// <summary>The maximum length of one Windows file-name component.</summary>
    public const int MaximumWindowsFileNameLength = 255;

    private static readonly char[] WindowsInvalidFileNameChars = ['<', '>', ':', '"', '/', '\\', '|', '?', '*'];
    private static readonly HashSet<string> WindowsReservedBaseNames = new(
        [
            "CON", "PRN", "AUX", "NUL",
            "COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9",
            "LPT1", "LPT2", "LPT3", "LPT4", "LPT5", "LPT6", "LPT7", "LPT8", "LPT9"
        ],
        StringComparer.OrdinalIgnoreCase);

    /// <summary>
    /// Replaces invalid file-name characters and applies a fallback for empty names.
    /// </summary>
    /// <param name="fileName">The untrusted source file name.</param>
    /// <param name="fallback">The name used when no usable characters remain.</param>
    /// <returns>A Windows-safe file name.</returns>
    public static string ToSafeFileName(string fileName, string fallback = "file")
    {
        var safeFileName = ReplaceWindowsInvalidCharacters(fileName).TrimEnd(' ', '.');
        if (string.IsNullOrWhiteSpace(safeFileName))
        {
            safeFileName = ReplaceWindowsInvalidCharacters(fallback).TrimEnd(' ', '.');
        }

        if (string.IsNullOrWhiteSpace(safeFileName))
        {
            safeFileName = "file";
        }

        var baseName = Path.GetFileNameWithoutExtension(safeFileName);
        if (WindowsReservedBaseNames.Contains(baseName))
        {
            safeFileName = $"_{safeFileName}";
        }

        return TruncatePreservingExtension(safeFileName, MaximumWindowsFileNameLength);
    }

    /// <summary>
    /// Adds a suffix before the extension while preserving the Windows component limit.
    /// </summary>
    public static bool TryAddSuffixBeforeExtension(string fileName, string suffix, out string result)
    {
        var extension = Path.GetExtension(fileName);
        var stem = fileName[..^extension.Length];
        var maximumStemLength = MaximumWindowsFileNameLength - extension.Length - suffix.Length;
        if (maximumStemLength < 1)
        {
            result = string.Empty;
            return false;
        }

        result = $"{stem[..Math.Min(stem.Length, maximumStemLength)]}{suffix}{extension}";
        return IsWindowsSafeFileName(result);
    }

    /// <summary>Returns whether a file name is already safe as one Windows path component.</summary>
    public static bool IsWindowsSafeFileName(string fileName)
    {
        return !string.IsNullOrWhiteSpace(fileName)
            && fileName.Length <= MaximumWindowsFileNameLength
            && string.Equals(fileName, ToSafeFileName(fileName), StringComparison.Ordinal);
    }

    /// <summary>
    /// Resolves the output file name for a macro reference while matching the original attachment name.
    /// </summary>
    public static string ResolveAttachmentOutputFileName(
        IEnumerable<AttachmentInfo> attachments,
        string originalFileName)
    {
        var attachment = attachments.FirstOrDefault(candidate =>
                candidate.FileName.Equals(originalFileName, StringComparison.Ordinal))
            ?? attachments.FirstOrDefault(candidate =>
                candidate.FileName.Equals(originalFileName, StringComparison.OrdinalIgnoreCase));

        return string.IsNullOrWhiteSpace(attachment?.OutputFileName)
            ? ToSafeFileName(originalFileName)
            : attachment.OutputFileName;
    }

    private static string ReplaceWindowsInvalidCharacters(string? fileName)
    {
        return new string((fileName ?? string.Empty)
            .Select(character => character < ' ' || WindowsInvalidFileNameChars.Contains(character) ? '_' : character)
            .ToArray());
    }

    private static string TruncatePreservingExtension(string fileName, int maximumLength)
    {
        if (fileName.Length <= maximumLength)
        {
            return fileName;
        }

        var extension = Path.GetExtension(fileName);
        var stem = fileName[..^extension.Length];
        var maximumStemLength = Math.Max(1, maximumLength - extension.Length);

        return $"{stem[..Math.Min(stem.Length, maximumStemLength)]}{extension}"[..maximumLength];
    }
}
