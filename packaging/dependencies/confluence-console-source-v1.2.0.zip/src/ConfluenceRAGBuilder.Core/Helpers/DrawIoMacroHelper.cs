using System;
using System.Collections.Generic;
using System.Linq;
using HtmlAgilityPack;

namespace ConfluenceRAGBuilder.Helpers;

/// <summary>
/// Reads draw.io attachment names referenced by Confluence storage-format macros.
/// </summary>
public static class DrawIoMacroHelper
{
    /// <summary>
    /// Extracts unique draw.io attachment names using case-insensitive matching.
    /// </summary>
    /// <param name="htmlStorageFormat">The Confluence storage-format HTML.</param>
    /// <returns>The referenced diagram names in discovery order.</returns>
    public static IReadOnlySet<string> ExtractDiagramNames(string htmlStorageFormat)
    {
        var names = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        if (string.IsNullOrWhiteSpace(htmlStorageFormat))
        {
            return names;
        }

        var doc = new HtmlDocument();
        doc.LoadHtml(htmlStorageFormat);

        var macros = doc.DocumentNode.Descendants("ac:structured-macro")
            .Where(n => n.GetAttributeValue("ac:name", "").Equals("drawio", StringComparison.OrdinalIgnoreCase));

        foreach (var macro in macros)
        {
            var name = ExtractDiagramName(macro);
            if (!string.IsNullOrWhiteSpace(name))
            {
                names.Add(name);
            }
        }

        return names;
    }

    private static string? ExtractDiagramName(HtmlNode macroNode)
    {
        var attachmentNode = macroNode.Descendants("ri:attachment").FirstOrDefault();
        var attachmentName = attachmentNode?.GetAttributeValue("ri:filename", "");
        if (!string.IsNullOrWhiteSpace(attachmentName))
        {
            return attachmentName;
        }

        return macroNode.Descendants("ac:parameter")
            .FirstOrDefault(n => new[] { "diagramName", "name", "filename", "fileName", "attachment", "diagramDisplayName" }
                .Contains(n.GetAttributeValue("ac:name", ""), StringComparer.OrdinalIgnoreCase))
            ?.InnerText;
    }
}
