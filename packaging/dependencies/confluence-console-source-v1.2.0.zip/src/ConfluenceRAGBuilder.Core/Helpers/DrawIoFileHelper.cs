using System;

namespace ConfluenceRAGBuilder.Helpers;

/// <summary>
/// Centralizes draw.io attachment file-name classification.
/// </summary>
public static class DrawIoFileHelper
{
    /// <summary>Determines whether a file name identifies draw.io XML.</summary>
    public static bool IsDrawIoXmlFileName(string fileName)
    {
        return !string.IsNullOrWhiteSpace(fileName)
            && (fileName.EndsWith(".drawio", StringComparison.OrdinalIgnoreCase)
                || fileName.EndsWith(".drawio.xml", StringComparison.OrdinalIgnoreCase));
    }

    /// <summary>Determines whether a file name identifies a PNG image.</summary>
    public static bool IsPngFileName(string fileName)
    {
        return !string.IsNullOrWhiteSpace(fileName)
            && fileName.EndsWith(".png", StringComparison.OrdinalIgnoreCase);
    }

    /// <summary>Determines whether a file may contain extractable draw.io content.</summary>
    public static bool IsDrawIoExtractionCandidate(string fileName)
    {
        return IsDrawIoXmlFileName(fileName) || IsPngFileName(fileName);
    }

    /// <summary>Builds the safe name for a readable draw.io Markdown companion file.</summary>
    public static string ToReadableMarkdownFileName(string fileName)
    {
        return FileNameHelper.ToSafeFileName(fileName, "diagram.drawio") + ".md";
    }
}
