// Author: Julien Bombled
// License: Apache 2.0

using System.Collections.Generic;
using HtmlAgilityPack;

namespace ConfluenceRAGBuilder.Services.Conversion;

internal interface IMacroProcessor
{
    IReadOnlyList<string> SupportedMacroNames { get; }
    void Process(HtmlNode macroNode, ConversionContext context);
}
