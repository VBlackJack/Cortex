// Author: Julien Bombled
// License: Apache 2.0

using System.Collections.Generic;
using System.Linq;
using ConfluenceRAGBuilder.Helpers;
using HtmlAgilityPack;

namespace ConfluenceRAGBuilder.Services.Conversion.MacroProcessors;

internal sealed class ViewFileProcessor : IMacroProcessor
{
    public IReadOnlyList<string> SupportedMacroNames => new[] { "view-file" };

    public void Process(HtmlNode macroNode, ConversionContext context)
    {
        var attachmentNode = macroNode.Descendants("ri:attachment").FirstOrDefault();
        var nameParameter = macroNode.Descendants("ac:parameter")
            .FirstOrDefault(n => n.GetAttributeValue("ac:name", "") == "name");

        var fileName = attachmentNode?.GetAttributeValue("ri:filename", "") ?? nameParameter?.InnerText ?? "";
        if (string.IsNullOrWhiteSpace(fileName))
        {
            macroNode.ParentNode.RemoveChild(macroNode);
            return;
        }

        var safeFileName = FileNameHelper.ResolveAttachmentOutputFileName(context.Attachments, fileName);
        var url = $"{context.AttachmentsRelativePath}{safeFileName}";
        var replacement = HtmlNode.CreateNode(
            $"<p><strong>📎 Fichier :</strong> <a href=\"{HtmlDocument.HtmlEncode(url)}\">{HtmlDocument.HtmlEncode(fileName)}</a></p>");

        macroNode.ParentNode.ReplaceChild(replacement, macroNode);
    }
}
