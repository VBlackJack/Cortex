// Author: Julien Bombled
// License: Apache 2.0

using System.Collections.Generic;
using System.Linq;
using ConfluenceRAGBuilder.Helpers;
using HtmlAgilityPack;

namespace ConfluenceRAGBuilder.Services.Conversion.MacroProcessors;

internal sealed class ImageProcessor : IMacroProcessor
{
    public IReadOnlyList<string> SupportedMacroNames => new[] { "ac:image" };

    public void Process(HtmlNode macroNode, ConversionContext context)
    {
        var attachmentNode = macroNode.Descendants("ri:attachment").FirstOrDefault();
        var urlNode = macroNode.Descendants("ri:url").FirstOrDefault();

        string url = "";
        string alt = "image";

        if (attachmentNode != null)
        {
            var filename = attachmentNode.GetAttributeValue("ri:filename", "");
            var safeFileName = FileNameHelper.ResolveAttachmentOutputFileName(context.Attachments, filename);
            url = $"{context.AttachmentsRelativePath}{safeFileName}";
            alt = filename;
        }
        else if (urlNode != null)
        {
            url = urlNode.GetAttributeValue("ri:value", "");
        }

        if (!string.IsNullOrEmpty(url))
        {
            var imgElement = HtmlNode.CreateNode($"<img src=\"{HtmlDocument.HtmlEncode(url)}\" alt=\"{HtmlDocument.HtmlEncode(alt)}\"/>");
            macroNode.ParentNode.ReplaceChild(imgElement, macroNode);
        }
        else
        {
            macroNode.ParentNode.RemoveChild(macroNode);
        }
    }
}
