// Author: Julien Bombled
// License: Apache 2.0

using System.Collections.Generic;
using System.Linq;
using ConfluenceRAGBuilder.Helpers;
using HtmlAgilityPack;

namespace ConfluenceRAGBuilder.Services.Conversion.MacroProcessors;

internal sealed class LinkProcessor : IMacroProcessor
{
    public IReadOnlyList<string> SupportedMacroNames => new[] { "ac:link" };

    public void Process(HtmlNode macroNode, ConversionContext context)
    {
        var attachmentNode = macroNode.Descendants("ri:attachment").FirstOrDefault();
        var pageNode = macroNode.Descendants("ri:page").FirstOrDefault();
        var urlNode = macroNode.Descendants("ri:url").FirstOrDefault();
        var userNode = macroNode.Descendants("ri:user").FirstOrDefault();

        var bodyNode = macroNode.Descendants("ac:plain-text-link-body").FirstOrDefault();

        string url = "#";
        string? displayText = bodyNode?.InnerText;

        if (attachmentNode != null)
        {
            var filename = attachmentNode.GetAttributeValue("ri:filename", "");
            var safeFileName = FileNameHelper.ResolveAttachmentOutputFileName(context.Attachments, filename);
            url = $"{context.AttachmentsRelativePath}{safeFileName}";
            displayText ??= filename;
        }
        else if (pageNode != null)
        {
            var contentTitle = pageNode.GetAttributeValue("ri:content-title", "");
            // Sanitize title for anchor
            url = $"#{contentTitle.Replace(" ", "-")}";
            displayText ??= contentTitle;
        }
        else if (urlNode != null)
        {
            url = urlNode.GetAttributeValue("ri:value", "#");
            displayText ??= url;
        }
        else if (userNode != null)
        {
            var userkey = userNode.GetAttributeValue("ri:userkey", "");
            var replacement = HtmlNode.CreateNode($"<span>@{HtmlDocument.HtmlEncode(userkey)}</span>");
            macroNode.ParentNode.ReplaceChild(replacement, macroNode);
            return;
        }

        displayText ??= "link";
        var linkElement = HtmlNode.CreateNode($"<a href=\"{HtmlDocument.HtmlEncode(url)}\">{HtmlDocument.HtmlEncode(displayText)}</a>");
        macroNode.ParentNode.ReplaceChild(linkElement, macroNode);
    }
}
