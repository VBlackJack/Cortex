// Author: Julien Bombled
// License: Apache 2.0

using System.Collections.Generic;
using System.Linq;
using HtmlAgilityPack;

namespace ConfluenceRAGBuilder.Services.Conversion.MacroProcessors;

internal sealed class ExpandProcessor : IMacroProcessor
{
    public IReadOnlyList<string> SupportedMacroNames => new[] { "expand", "ui-expand", "details", "sp-expander-box" };

    public void Process(HtmlNode macroNode, ConversionContext context)
    {
        var titleNode = macroNode.Descendants("ac:parameter").FirstOrDefault(n => n.GetAttributeValue("ac:name", "") == "title");
        var bodyNode = macroNode.Descendants("ac:rich-text-body").FirstOrDefault();

        var title = titleNode?.InnerText ?? "Détails";
        var contentHtml = bodyNode?.InnerHtml ?? "";

        var replacement = HtmlNode.CreateNode($"<details><summary>{HtmlDocument.HtmlEncode(title)}</summary><div></div></details>");
        replacement.LastChild.InnerHtml = contentHtml;

        macroNode.ParentNode.ReplaceChild(replacement, macroNode);
    }
}
