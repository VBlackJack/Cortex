// Author: Julien Bombled
// License: Apache 2.0

using System.Collections.Generic;
using System.Linq;
using HtmlAgilityPack;

namespace ConfluenceRAGBuilder.Services.Conversion.MacroProcessors;

internal sealed class QuoteProcessor : IMacroProcessor
{
    public IReadOnlyList<string> SupportedMacroNames => new[] { "quote" };

    public void Process(HtmlNode macroNode, ConversionContext context)
    {
        var bodyNode = macroNode.Descendants("ac:rich-text-body").FirstOrDefault();
        var contentHtml = bodyNode?.InnerHtml ?? "";

        if (string.IsNullOrWhiteSpace(contentHtml))
        {
            macroNode.ParentNode.RemoveChild(macroNode);
            return;
        }

        var replacement = HtmlNode.CreateNode("<blockquote></blockquote>");
        replacement.InnerHtml = contentHtml;
        macroNode.ParentNode.ReplaceChild(replacement, macroNode);
    }
}
