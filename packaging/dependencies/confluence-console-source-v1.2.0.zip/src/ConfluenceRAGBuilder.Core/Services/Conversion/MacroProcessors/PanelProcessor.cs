// Author: Julien Bombled
// License: Apache 2.0

using System.Collections.Generic;
using System.Linq;
using HtmlAgilityPack;

namespace ConfluenceRAGBuilder.Services.Conversion.MacroProcessors;

internal sealed class PanelProcessor : IMacroProcessor
{
    public IReadOnlyList<string> SupportedMacroNames => new[] { "info", "note", "warning", "tip", "panel" };

    public void Process(HtmlNode macroNode, ConversionContext context)
    {
        var acName = macroNode.GetAttributeValue("ac:name", "panel");
        var titleNode = macroNode.Descendants("ac:parameter").FirstOrDefault(n => n.GetAttributeValue("ac:name", "") == "title");
        var bodyNode = macroNode.Descendants("ac:rich-text-body").FirstOrDefault();

        var title = titleNode?.InnerText;
        var contentHtml = bodyNode?.InnerHtml ?? "";

        string emoji;
        string defaultLabel;

        switch (acName)
        {
            case "info": emoji = "ℹ️"; defaultLabel = "INFO"; break;
            case "note": emoji = "📝"; defaultLabel = "NOTE"; break;
            case "warning": emoji = "⚠️"; defaultLabel = "WARNING"; break;
            case "tip": emoji = "💡"; defaultLabel = "TIP"; break;
            default: emoji = "📋"; defaultLabel = "PANEL"; break;
        }

        var label = string.IsNullOrEmpty(title) ? defaultLabel : title;

        var replacement = HtmlNode.CreateNode($"<blockquote><p><strong>{emoji} {HtmlDocument.HtmlEncode(label)} :</strong></p></blockquote>");
        replacement.InnerHtml += contentHtml;

        macroNode.ParentNode.ReplaceChild(replacement, macroNode);
    }
}
