// Author: Julien Bombled
// License: Apache 2.0

using System.Collections.Generic;
using System.Linq;
using HtmlAgilityPack;

namespace ConfluenceRAGBuilder.Services.Conversion.MacroProcessors;

internal sealed class TableProcessor : IMacroProcessor
{
    public IReadOnlyList<string> SupportedMacroNames => new[] { "table" };

    public void Process(HtmlNode macroNode, ConversionContext context)
    {
        // HtmlAgilityPack and ReverseMarkdown handle standard tables mostly well.
        // We might just need to ensure headers exist or clean up Confluence specific classes.
        // For now, this is a pass-through or cleanup.
        // Confluence tables use <tbody><tr><th>. ReverseMarkdown works better if <th> is in <thead>.

        var tbody = macroNode.Descendants("tbody").FirstOrDefault();
        if (tbody != null)
        {
            var firstRow = tbody.Descendants("tr").FirstOrDefault();
            if (firstRow != null && firstRow.Descendants("th").FirstOrDefault() != null)
            {
                var thead = HtmlNode.CreateNode("<thead></thead>");
                thead.AppendChild(firstRow.CloneNode(true));
                macroNode.InsertBefore(thead, tbody);
                firstRow.Remove();
            }
        }
    }
}
