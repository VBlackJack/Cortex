// Author: Julien Bombled
// License: Apache 2.0

using System.Collections.Generic;
using System.Linq;
using HtmlAgilityPack;
using Markdig;

namespace ConfluenceRAGBuilder.Services.Conversion.MacroProcessors;

internal sealed class MarkdownMacroProcessor : IMacroProcessor
{
    // Disable raw HTML passthrough to prevent XSS from user-authored Markdown content
    private static readonly MarkdownPipeline SafePipeline = new MarkdownPipelineBuilder()
        .DisableHtml()
        .Build();

    public IReadOnlyList<string> SupportedMacroNames => new[] { "markdown" };

    public void Process(HtmlNode macroNode, ConversionContext context)
    {
        var plainTextBody = macroNode.Descendants("ac:plain-text-body").FirstOrDefault();
        var richTextBody = macroNode.Descendants("ac:rich-text-body").FirstOrDefault();

        var replacement = HtmlNode.CreateNode("<div></div>");
        if (plainTextBody != null)
        {
            replacement.InnerHtml = Markdown.ToHtml(PlainTextBodyExtractor.Extract(plainTextBody), SafePipeline);
        }
        else if (richTextBody != null)
        {
            replacement.InnerHtml = richTextBody.InnerHtml;
        }

        macroNode.ParentNode.ReplaceChild(replacement, macroNode);
    }
}
