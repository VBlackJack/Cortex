// Author: Julien Bombled
// License: Apache 2.0

using System;
using System.Linq;
using HtmlAgilityPack;

namespace ConfluenceRAGBuilder.Services.Conversion.MacroProcessors;

internal static class PlainTextBodyExtractor
{
    private const string CDataStart = "<![CDATA[";
    private const string CDataEnd = "]]>";

    public static string Extract(HtmlNode? plainTextBody)
    {
        if (plainTextBody == null) return string.Empty;

        var cdataText = string.Concat(plainTextBody.ChildNodes
            .Where(node => node.NodeType == HtmlNodeType.Comment && IsCData(node.OuterHtml))
            .Select(node => UnwrapCData(node.OuterHtml)));

        return cdataText.Length > 0
            ? cdataText
            : plainTextBody.InnerText;
    }

    private static bool IsCData(string value)
    {
        return value.StartsWith(CDataStart, StringComparison.Ordinal)
            && value.EndsWith(CDataEnd, StringComparison.Ordinal);
    }

    private static string UnwrapCData(string value)
    {
        return value.Substring(CDataStart.Length, value.Length - CDataStart.Length - CDataEnd.Length);
    }
}
