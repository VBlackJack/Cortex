// Author: Julien Bombled
// License: Apache 2.0

using System.Collections.Generic;
using System.Linq;
using HtmlAgilityPack;

namespace ConfluenceRAGBuilder.Services.Conversion.MacroProcessors;

internal sealed class FallbackProcessor : IMacroProcessor
{
    public IReadOnlyList<string> SupportedMacroNames => new[] { "*" }; // Matches anything not matched before

    public void Process(HtmlNode macroNode, ConversionContext context)
    {
        var acName = macroNode.GetAttributeValue("ac:name", "unknown");

        var richTextBody = macroNode.Descendants("ac:rich-text-body").FirstOrDefault();
        var plainTextBody = macroNode.Descendants("ac:plain-text-body").FirstOrDefault();

        HtmlNode replacement;

        if (richTextBody != null)
        {
            replacement = HtmlNode.CreateNode("<div></div>");
            replacement.InnerHtml = richTextBody.InnerHtml;
        }
        else if (plainTextBody != null)
        {
            replacement = HtmlNode.CreateNode("<div></div>");
            replacement.InnerHtml = HtmlDocument.HtmlEncode(PlainTextBodyExtractor.Extract(plainTextBody));
        }
        else
        {
            replacement = HtmlNode.CreateNode($"<em>[Macro non supportée : {HtmlDocument.HtmlEncode(acName)}]</em>");
        }

        context.Warnings.Add(new ConversionWarning
        {
            MacroName = acName,
            Message = $"Macro '{acName}' non supportée - contenu extrait en fallback",
            Context = replacement.InnerText.Length > 100 ? replacement.InnerText.Substring(0, 100) + "..." : replacement.InnerText
        });

        macroNode.ParentNode.ReplaceChild(replacement, macroNode);
    }
}
