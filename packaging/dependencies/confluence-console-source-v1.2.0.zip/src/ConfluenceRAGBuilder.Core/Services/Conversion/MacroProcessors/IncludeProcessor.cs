// Author: Julien Bombled
// License: Apache 2.0

using System.Collections.Generic;
using System.Linq;
using HtmlAgilityPack;

namespace ConfluenceRAGBuilder.Services.Conversion.MacroProcessors;

internal sealed class IncludeProcessor : IMacroProcessor
{
    public IReadOnlyList<string> SupportedMacroNames => new[] { "include", "excerpt-include", "table-excerpt-include" };

    public void Process(HtmlNode macroNode, ConversionContext context)
    {
        // Include macros transclude content from another page.
        // We cannot fetch the remote page during conversion, so render a reference.
        var pageNode = macroNode.Descendants("ri:page").FirstOrDefault();
        var pageTitle = pageNode?.GetAttributeValue("ri:content-title", "")
                     ?? pageNode?.GetAttributeValue("ri:title", "");

        var spaceKey = pageNode?.GetAttributeValue("ri:space-key", "");

        string label;
        if (!string.IsNullOrEmpty(pageTitle))
        {
            var spacePart = !string.IsNullOrEmpty(spaceKey) ? $"{spaceKey}:" : "";
            label = $"{spacePart}{pageTitle}";
        }
        else
        {
            label = macroNode.GetAttributeValue("ac:name", "include");
        }

        var safeLabel = HtmlDocument.HtmlEncode(label);
        var replacement = HtmlNode.CreateNode($"<p><em>[Included: {safeLabel}]</em></p>");
        macroNode.ParentNode.ReplaceChild(replacement, macroNode);
    }
}
