// Author: Julien Bombled
// License: Apache 2.0

using System.Collections.Generic;
using System.Linq;
using HtmlAgilityPack;

namespace ConfluenceRAGBuilder.Services.Conversion.MacroProcessors;

internal sealed class HtmlMacroProcessor : IMacroProcessor
{
    public IReadOnlyList<string> SupportedMacroNames => new[] { "html" };

    public void Process(HtmlNode macroNode, ConversionContext context)
    {
        // The HTML macro contains raw HTML in a plain-text-body (CDATA).
        // Extract the content and inject it for downstream ReverseMarkdown processing.
        var plainTextBody = macroNode.Descendants("ac:plain-text-body").FirstOrDefault();
        if (plainTextBody != null)
        {
            var rawHtml = PlainTextBodyExtractor.Extract(plainTextBody);
            if (!string.IsNullOrWhiteSpace(rawHtml))
            {
                var replacement = HtmlNode.CreateNode("<div></div>");
                replacement.InnerHtml = rawHtml;
                macroNode.ParentNode.ReplaceChild(replacement, macroNode);
                return;
            }
        }

        // Fallback: try rich-text-body
        var richTextBody = macroNode.Descendants("ac:rich-text-body").FirstOrDefault();
        if (richTextBody != null && !string.IsNullOrWhiteSpace(richTextBody.InnerHtml))
        {
            var replacement = HtmlNode.CreateNode("<div></div>");
            replacement.InnerHtml = richTextBody.InnerHtml;
            macroNode.ParentNode.ReplaceChild(replacement, macroNode);
            return;
        }

        macroNode.ParentNode.RemoveChild(macroNode);
    }
}
