// Author: Julien Bombled
// License: Apache 2.0

using System.Collections.Generic;
using System.Linq;
using HtmlAgilityPack;

namespace ConfluenceRAGBuilder.Services.Conversion.MacroProcessors;

internal sealed class TocProcessor : IMacroProcessor
{
    public IReadOnlyList<string> SupportedMacroNames => new[] { "toc", "toc-zone" };

    public void Process(HtmlNode macroNode, ConversionContext context)
    {
        var macroName = macroNode.GetAttributeValue("ac:name", "");

        if (macroName == "toc-zone")
        {
            // toc-zone wraps content with a TOC sidebar - keep the body content
            var bodyNode = macroNode.Descendants("ac:rich-text-body").FirstOrDefault();
            if (bodyNode != null)
            {
                var replacement = HtmlNode.CreateNode("<div></div>");
                replacement.InnerHtml = bodyNode.InnerHtml;
                macroNode.ParentNode.ReplaceChild(replacement, macroNode);
                return;
            }
        }

        // toc: remove entirely (navigation widget, not content)
        macroNode.ParentNode.RemoveChild(macroNode);
    }
}
