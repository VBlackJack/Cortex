// Author: Julien Bombled
// License: Apache 2.0

using System.Collections.Generic;
using System.Linq;
using HtmlAgilityPack;

namespace ConfluenceRAGBuilder.Services.Conversion.MacroProcessors;

internal sealed class TaskListProcessor : IMacroProcessor
{
    public IReadOnlyList<string> SupportedMacroNames => new[] { "ac:task-list" };

    public void Process(HtmlNode macroNode, ConversionContext context)
    {
        var ulNode = HtmlNode.CreateNode("<ul></ul>");

        var tasks = macroNode.Descendants("ac:task").ToList();
        if (tasks.Any())
        {
            foreach (var task in tasks)
            {
                var statusNode = task.Descendants("ac:task-status").FirstOrDefault();
                var bodyNode = task.Descendants("ac:task-body").FirstOrDefault();

                var status = statusNode?.InnerText == "complete" ? "[x]" : "[ ]";
                var bodyHtml = bodyNode?.InnerHtml ?? "";

                var liNode = HtmlNode.CreateNode($"<li>{status} <span></span></li>");
                var spanNode = liNode.Descendants("span").FirstOrDefault();
                if (spanNode != null)
                {
                    spanNode.InnerHtml = bodyHtml;
                }
                ulNode.AppendChild(liNode);
            }
        }

        macroNode.ParentNode.ReplaceChild(ulNode, macroNode);
    }
}
