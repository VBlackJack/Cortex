// Author: Julien Bombled
// License: Apache 2.0

using System.Collections.Generic;
using System.Linq;
using HtmlAgilityPack;

namespace ConfluenceRAGBuilder.Services.Conversion.MacroProcessors;

internal sealed class ExcerptProcessor : IMacroProcessor
{
    public IReadOnlyList<string> SupportedMacroNames => new[] { "excerpt", "multiexcerpt" };

    public void Process(HtmlNode macroNode, ConversionContext context)
    {
        // Excerpt macro wraps a section of content that can be transcluded elsewhere.
        // Extract the body content directly - it's normal page content.
        var richTextBody = macroNode.Descendants("ac:rich-text-body").FirstOrDefault();
        if (richTextBody != null && !string.IsNullOrWhiteSpace(richTextBody.InnerHtml))
        {
            var replacement = HtmlNode.CreateNode("<div></div>");
            replacement.InnerHtml = richTextBody.InnerHtml;
            macroNode.ParentNode.ReplaceChild(replacement, macroNode);
        }
        else
        {
            macroNode.ParentNode.RemoveChild(macroNode);
        }
    }
}
