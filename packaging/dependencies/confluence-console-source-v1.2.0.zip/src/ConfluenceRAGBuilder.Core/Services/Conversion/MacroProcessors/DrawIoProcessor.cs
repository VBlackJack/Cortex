// Author: Julien Bombled
// License: Apache 2.0

using System.Collections.Generic;
using System.IO;
using System.Linq;
using ConfluenceRAGBuilder.Helpers;
using ConfluenceRAGBuilder.Models;
using HtmlAgilityPack;

namespace ConfluenceRAGBuilder.Services.Conversion.MacroProcessors;

internal sealed class DrawIoProcessor : IMacroProcessor
{
    public IReadOnlyList<string> SupportedMacroNames => new[] { "drawio", "inc-drawio", "drawio-sketch", "drawio-sketch-border" };

    public void Process(HtmlNode macroNode, ConversionContext context)
    {
        var diagramName = GetDiagramName(macroNode);
        if (string.IsNullOrWhiteSpace(diagramName))
        {
            var placeholder = HtmlNode.CreateNode("<p><em>[Diagramme draw.io]</em></p>");
            macroNode.ParentNode.ReplaceChild(placeholder, macroNode);
            return;
        }

        var attachment = FindMatchingAttachment(context, diagramName);
        var linkedFileName = attachment?.FileName ?? diagramName;
        var safeFileName = !string.IsNullOrWhiteSpace(attachment?.DrawIoTextPath)
            ? Path.GetFileName(attachment.DrawIoTextPath)
            : FileNameHelper.ResolveAttachmentOutputFileName(context.Attachments, linkedFileName);
        var url = $"{context.AttachmentsRelativePath}{safeFileName}";

        var replacement = HtmlNode.CreateNode(
            $"<p><strong>Diagramme draw.io :</strong> <a href=\"{HtmlDocument.HtmlEncode(url)}\">{HtmlDocument.HtmlEncode(diagramName)}</a></p>");

        macroNode.ParentNode.ReplaceChild(replacement, macroNode);
    }

    private static string? GetDiagramName(HtmlNode macroNode)
    {
        var attachmentNode = macroNode.Descendants("ri:attachment").FirstOrDefault();
        var attachmentName = attachmentNode?.GetAttributeValue("ri:filename", "");
        if (!string.IsNullOrWhiteSpace(attachmentName))
        {
            return attachmentName;
        }

        return GetParameterValue(macroNode, "diagramName", "name", "filename", "fileName", "attachment", "diagramDisplayName");
    }

    private static AttachmentInfo? FindMatchingAttachment(ConversionContext context, string diagramName)
    {
        return context.Attachments.FirstOrDefault(a => a.FileName.Equals(diagramName, System.StringComparison.OrdinalIgnoreCase))
            ?? context.Attachments.FirstOrDefault(a => Path.GetFileNameWithoutExtension(a.FileName).Equals(diagramName, System.StringComparison.OrdinalIgnoreCase))
            ?? context.Attachments.FirstOrDefault(a => a.FileName.Contains(diagramName, System.StringComparison.OrdinalIgnoreCase));
    }

    private static string? GetParameterValue(HtmlNode macroNode, params string[] names)
    {
        return macroNode.Descendants("ac:parameter")
            .FirstOrDefault(n => names.Contains(n.GetAttributeValue("ac:name", ""), System.StringComparer.OrdinalIgnoreCase))
            ?.InnerText;
    }
}
