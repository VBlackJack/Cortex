// Author: Julien Bombled
// License: Apache 2.0

using System.Collections.Generic;
using System.Linq;
using HtmlAgilityPack;

namespace ConfluenceRAGBuilder.Services.Conversion.MacroProcessors;

internal sealed class StatusProcessor : IMacroProcessor
{
    public IReadOnlyList<string> SupportedMacroNames => new[] { "status", "easy-dropdown-menu-status", "pagestatus" };

    public void Process(HtmlNode macroNode, ConversionContext context)
    {
        var titleNode = GetParameter(macroNode, "title", "text", "value", "status", "selected");
        var colorNode = GetParameter(macroNode, "colour", "color");

        var title = titleNode?.InnerText ?? "STATUS";
        var color = colorNode?.InnerText?.ToUpper() ?? "GREY";

        var replacement = HtmlNode.CreateNode($"<code>[{HtmlDocument.HtmlEncode(color)}: {HtmlDocument.HtmlEncode(title)}]</code>");

        macroNode.ParentNode.ReplaceChild(replacement, macroNode);
    }

    private static HtmlNode? GetParameter(HtmlNode macroNode, params string[] names)
    {
        return macroNode.Descendants("ac:parameter")
            .FirstOrDefault(n => names.Contains(n.GetAttributeValue("ac:name", ""), System.StringComparer.OrdinalIgnoreCase));
    }
}
