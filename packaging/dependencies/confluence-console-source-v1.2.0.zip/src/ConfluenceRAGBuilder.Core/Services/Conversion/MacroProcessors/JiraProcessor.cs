// Author: Julien Bombled
// License: Apache 2.0

using System.Collections.Generic;
using System.Linq;
using HtmlAgilityPack;

namespace ConfluenceRAGBuilder.Services.Conversion.MacroProcessors;

internal sealed class JiraProcessor : IMacroProcessor
{
    public IReadOnlyList<string> SupportedMacroNames => new[] { "jira", "jirachart" };

    public void Process(HtmlNode macroNode, ConversionContext context)
    {
        var key = GetParameterValue(macroNode, "key");
        var serverId = GetParameterValue(macroNode, "serverId");
        var server = GetParameterValue(macroNode, "server");
        var jqlQuery = GetParameterValue(macroNode, "jqlQuery");

        if (!string.IsNullOrEmpty(key))
        {
            // Single issue reference: render as inline ticket link
            var safeKey = HtmlDocument.HtmlEncode(key);
            var replacement = HtmlNode.CreateNode($"<strong>[{safeKey}]</strong>");
            macroNode.ParentNode.ReplaceChild(replacement, macroNode);
            return;
        }

        if (!string.IsNullOrEmpty(jqlQuery))
        {
            // JQL query (issue table): render as descriptive placeholder
            var safeQuery = HtmlDocument.HtmlEncode(jqlQuery);
            var replacement = HtmlNode.CreateNode($"<p><em>[JIRA: {safeQuery}]</em></p>");
            macroNode.ParentNode.ReplaceChild(replacement, macroNode);
            return;
        }

        // Fallback: extract any body content or show placeholder
        var bodyNode = macroNode.Descendants("ac:rich-text-body").FirstOrDefault();
        if (bodyNode != null)
        {
            var replacement = HtmlNode.CreateNode("<span></span>");
            replacement.InnerHtml = bodyNode.InnerHtml;
            macroNode.ParentNode.ReplaceChild(replacement, macroNode);
        }
        else
        {
            var replacement = HtmlNode.CreateNode("<em>[JIRA]</em>");
            macroNode.ParentNode.ReplaceChild(replacement, macroNode);
        }
    }

    private static string? GetParameterValue(HtmlNode macroNode, params string[] names)
    {
        return macroNode.Descendants("ac:parameter")
            .FirstOrDefault(n => names.Contains(n.GetAttributeValue("ac:name", ""), System.StringComparer.OrdinalIgnoreCase))
            ?.InnerText;
    }
}
