// Author: Julien Bombled
// License: Apache 2.0

using System.Collections.Generic;
using System.Linq;
using HtmlAgilityPack;

namespace ConfluenceRAGBuilder.Services.Conversion.MacroProcessors;

internal sealed class AnchorProcessor : IMacroProcessor
{
    public IReadOnlyList<string> SupportedMacroNames => new[] { "anchor" };

    public void Process(HtmlNode macroNode, ConversionContext context)
    {
        // Anchor macros create named bookmarks in the page.
        // In Markdown, anchors are invisible - simply remove the macro.
        var anchorName = macroNode.Descendants("ac:parameter")
            .FirstOrDefault(n => string.IsNullOrEmpty(n.GetAttributeValue("ac:name", "")))
            ?.InnerText;

        if (!string.IsNullOrEmpty(anchorName))
        {
            // Preserve as an HTML anchor tag for potential internal linking
            var safeId = HtmlDocument.HtmlEncode(anchorName);
            var replacement = HtmlNode.CreateNode($"<a id=\"{safeId}\"></a>");
            macroNode.ParentNode.ReplaceChild(replacement, macroNode);
        }
        else
        {
            macroNode.ParentNode.RemoveChild(macroNode);
        }
    }
}
