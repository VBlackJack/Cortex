// Author: Julien Bombled
// License: Apache 2.0

using System.Collections.Generic;
using System.Linq;
using HtmlAgilityPack;

namespace ConfluenceRAGBuilder.Services.Conversion.MacroProcessors;

internal sealed class BodyMacroProcessor : IMacroProcessor
{
    public IReadOnlyList<string> SupportedMacroNames => new[]
    {
        "section",
        "column",
        "ui-steps",
        "ui-step",
        "table-filter",
        "easy-heading-free",
        "aui-tab",
        "aui-tab-group",
        "table-excerpt",
        "sp-macro-panels",
        "layout-width",
        "detailssummary",
        "ui-tab",
        "ui-tabs",
        "table-chart",
        "table-joiner",
        "ui-image"
    };

    public void Process(HtmlNode macroNode, ConversionContext context)
    {
        var macroName = macroNode.GetAttributeValue("ac:name", "");
        if (macroName.Equals("easy-heading-free", System.StringComparison.OrdinalIgnoreCase))
        {
            ProcessHeading(macroNode);
            return;
        }

        ReplaceWithBody(macroNode);
    }

    // The bodyHtml originates from Confluence storage format (ac:rich-text-body) which is
    // server-side generated HTML. It is subsequently processed by ReverseMarkdown to produce
    // Markdown output, so HTML content does not propagate to the final text output.
    private static void ProcessHeading(HtmlNode macroNode)
    {
        var title = GetParameterValue(macroNode, "title", "heading", "text", "name")
            ?? macroNode.Descendants("ac:parameter").Select(n => n.InnerText).FirstOrDefault(s => !string.IsNullOrWhiteSpace(s));
        var bodyHtml = ExtractBodyHtml(macroNode);

        if (string.IsNullOrWhiteSpace(title) && string.IsNullOrWhiteSpace(bodyHtml))
        {
            macroNode.ParentNode.RemoveChild(macroNode);
            return;
        }

        var replacement = HtmlNode.CreateNode("<div></div>");

        if (!string.IsNullOrWhiteSpace(title))
        {
            replacement.AppendChild(HtmlNode.CreateNode($"<h2>{HtmlDocument.HtmlEncode(title)}</h2>"));
        }

        if (!string.IsNullOrWhiteSpace(bodyHtml))
        {
            var bodyNode = HtmlNode.CreateNode("<div></div>");
            bodyNode.InnerHtml = bodyHtml;
            replacement.AppendChild(bodyNode);
        }

        macroNode.ParentNode.ReplaceChild(replacement, macroNode);
    }

    private static void ReplaceWithBody(HtmlNode macroNode)
    {
        var bodyHtml = ExtractBodyHtml(macroNode);

        if (string.IsNullOrWhiteSpace(bodyHtml))
        {
            macroNode.ParentNode.RemoveChild(macroNode);
            return;
        }

        var replacement = HtmlNode.CreateNode("<div></div>");
        replacement.InnerHtml = bodyHtml;
        macroNode.ParentNode.ReplaceChild(replacement, macroNode);
    }

    private static string ExtractBodyHtml(HtmlNode macroNode)
    {
        var richTextBody = GetOwnBody(macroNode, "ac:rich-text-body");
        if (richTextBody != null)
        {
            return richTextBody.InnerHtml;
        }

        var plainTextBody = GetOwnBody(macroNode, "ac:plain-text-body");
        if (plainTextBody != null)
        {
            return HtmlDocument.HtmlEncode(PlainTextBodyExtractor.Extract(plainTextBody));
        }

        return string.Empty;
    }

    private static HtmlNode? GetOwnBody(HtmlNode macroNode, string name)
    {
        return macroNode.ChildNodes.FirstOrDefault(n => n.Name == name);
    }

    private static string? GetParameterValue(HtmlNode macroNode, params string[] names)
    {
        return macroNode.Descendants("ac:parameter")
            .FirstOrDefault(n => names.Contains(n.GetAttributeValue("ac:name", ""), System.StringComparer.OrdinalIgnoreCase))
            ?.InnerText;
    }
}
