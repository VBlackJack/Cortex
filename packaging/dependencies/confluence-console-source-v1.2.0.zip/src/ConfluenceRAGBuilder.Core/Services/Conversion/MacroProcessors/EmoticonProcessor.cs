// Author: Julien Bombled
// License: Apache 2.0

using System.Collections.Generic;
using HtmlAgilityPack;

namespace ConfluenceRAGBuilder.Services.Conversion.MacroProcessors;

internal sealed class EmoticonProcessor : IMacroProcessor
{
    public IReadOnlyList<string> SupportedMacroNames => new[] { "ac:emoticon" };

    public void Process(HtmlNode macroNode, ConversionContext context)
    {
        var acName = macroNode.GetAttributeValue("ac:name", "");

        string emoji = acName switch
        {
            "smile" => "😊",
            "sad" => "😢",
            "cheeky" => "😜",
            "laugh" => "😄",
            "wink" => "😉",
            "thumbs-up" => "👍",
            "thumbs-down" => "👎",
            "information" => "ℹ️",
            "tick" => "✅",
            "cross" => "❌",
            "warning" => "⚠️",
            "question" => "❓",
            "light-on" => "💡",
            "yellow-star" => "⭐",
            "heart" => "❤️",
            _ => $":{acName}:" // fallback
        };

        var replacement = HtmlNode.CreateNode($"<span>{emoji}</span>");
        macroNode.ParentNode.ReplaceChild(replacement, macroNode);
    }
}
