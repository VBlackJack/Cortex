// Author: Julien Bombled
// License: Apache 2.0

using System.Collections.Generic;
using System.Linq;
using HtmlAgilityPack;

namespace ConfluenceRAGBuilder.Services.Conversion.MacroProcessors;

internal sealed class CodeBlockProcessor : IMacroProcessor
{
    public IReadOnlyList<string> SupportedMacroNames => new[] { "code", "noformat", "unmigrated-wiki-markup" };

    public void Process(HtmlNode macroNode, ConversionContext context)
    {
        var languageNode = macroNode.Descendants("ac:parameter").FirstOrDefault(n => n.GetAttributeValue("ac:name", "") == "language");
        var titleNode = macroNode.Descendants("ac:parameter").FirstOrDefault(n => n.GetAttributeValue("ac:name", "") == "title");
        var bodyNode = macroNode.Descendants("ac:plain-text-body").FirstOrDefault();

        var language = languageNode?.InnerText ?? "text";
        var title = titleNode?.InnerText;
        var code = PlainTextBodyExtractor.Extract(bodyNode);

        var replacement = HtmlNode.CreateNode("<div></div>");

        if (!string.IsNullOrEmpty(title))
        {
            var pNode = HtmlNode.CreateNode($"<p><em>📝 {HtmlDocument.HtmlEncode(title)}</em></p>");
            replacement.AppendChild(pNode);
        }

        var preNode = HtmlNode.CreateNode($"<pre><code class=\"language-{HtmlDocument.HtmlEncode(language)}\"></code></pre>");
        preNode.FirstChild.InnerHtml = HtmlDocument.HtmlEncode(code); // HtmlAgilityPack doesn't auto-encode InnerText properly in all contexts
        replacement.AppendChild(preNode);

        macroNode.ParentNode.ReplaceChild(replacement, macroNode);
    }
}
