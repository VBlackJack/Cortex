// Author: Julien Bombled
// License: Apache 2.0

using System.Collections.Generic;
using System.Linq;
using ConfluenceRAGBuilder.Helpers;
using HtmlAgilityPack;

namespace ConfluenceRAGBuilder.Services.Conversion.MacroProcessors;

internal sealed class GliffyProcessor : IMacroProcessor
{
    public IReadOnlyList<string> SupportedMacroNames => new[] { "gliffy" };

    public void Process(HtmlNode macroNode, ConversionContext context)
    {
        var name = macroNode.Descendants("ac:parameter")
            .FirstOrDefault(n => n.GetAttributeValue("ac:name", "") == "name")
            ?.InnerText ?? "Diagram";

        // Check if there's an attachment reference for the Gliffy image
        var attachmentNode = macroNode.Descendants("ri:attachment").FirstOrDefault();
        if (attachmentNode != null)
        {
            var filename = attachmentNode.GetAttributeValue("ri:filename", "");
            if (!string.IsNullOrEmpty(filename))
            {
                var safeFileName = FileNameHelper.ResolveAttachmentOutputFileName(context.Attachments, filename);
                var url = $"{context.AttachmentsRelativePath}{safeFileName}";
                var safeUrl = HtmlDocument.HtmlEncode(url);
                var safeName = HtmlDocument.HtmlEncode(name);
                var replacement = HtmlNode.CreateNode($"<p><img src=\"{safeUrl}\" alt=\"{safeName}\"/></p>");
                macroNode.ParentNode.ReplaceChild(replacement, macroNode);
                return;
            }
        }

        // No attachment - render as placeholder
        var safeLabel = HtmlDocument.HtmlEncode(name);
        var placeholderReplacement = HtmlNode.CreateNode($"<p><em>[Gliffy: {safeLabel}]</em></p>");
        macroNode.ParentNode.ReplaceChild(placeholderReplacement, macroNode);
    }
}
