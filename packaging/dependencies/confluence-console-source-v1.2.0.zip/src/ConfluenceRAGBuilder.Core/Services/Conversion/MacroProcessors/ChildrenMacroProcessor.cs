// Author: Julien Bombled
// License: Apache 2.0

using System.Collections.Generic;
using HtmlAgilityPack;

namespace ConfluenceRAGBuilder.Services.Conversion.MacroProcessors;

internal sealed class ChildrenMacroProcessor : IMacroProcessor
{
    public IReadOnlyList<string> SupportedMacroNames => new[] { "children", "ui-children", "ui-children-cards" };

    public void Process(HtmlNode macroNode, ConversionContext context)
    {
        var replacement = HtmlNode.CreateNode("<em>[Sous-pages...]</em>");
        macroNode.ParentNode.ReplaceChild(replacement, macroNode);
    }
}
