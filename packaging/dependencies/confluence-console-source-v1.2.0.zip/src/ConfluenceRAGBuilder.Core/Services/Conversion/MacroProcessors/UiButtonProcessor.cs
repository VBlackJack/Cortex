// Author: Julien Bombled
// License: Apache 2.0

using System.Collections.Generic;
using System.Linq;
using HtmlAgilityPack;

namespace ConfluenceRAGBuilder.Services.Conversion.MacroProcessors;

internal sealed class UiButtonProcessor : IMacroProcessor
{
    public IReadOnlyList<string> SupportedMacroNames => new[] { "ui-button", "sp-macro-button", "button" };

    public void Process(HtmlNode macroNode, ConversionContext context)
    {
        var title = macroNode.Descendants("ac:parameter")
            .FirstOrDefault(n => n.GetAttributeValue("ac:name", "") == "title")
            ?.InnerText;

        var bodyNode = macroNode.Descendants("ac:rich-text-body").FirstOrDefault();

        // If the button has a body (typically a link), extract it
        if (bodyNode != null && !string.IsNullOrWhiteSpace(bodyNode.InnerHtml))
        {
            var replacement = HtmlNode.CreateNode("<span></span>");
            replacement.InnerHtml = bodyNode.InnerHtml;
            macroNode.ParentNode.ReplaceChild(replacement, macroNode);
            return;
        }

        // Otherwise render the title as bold inline text
        var label = HtmlDocument.HtmlEncode(title ?? "Button");
        var buttonReplacement = HtmlNode.CreateNode($"<strong>[{label}]</strong>");
        macroNode.ParentNode.ReplaceChild(buttonReplacement, macroNode);
    }
}
