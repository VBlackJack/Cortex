// Author: Julien Bombled
// License: Apache 2.0

using System.Collections.Generic;
using HtmlAgilityPack;

namespace ConfluenceRAGBuilder.Services.Conversion.MacroProcessors;

internal sealed class DynamicContentProcessor : IMacroProcessor
{
    public IReadOnlyList<string> SupportedMacroNames => new[]
    {
        "recently-updated",
        "content-report-table",
        "popular-labels",
        "related-labels",
        "navmap",
        "livesearch",
        "content-by-label",
        "change-history",
        "contributors",
        "contributors-summary",
        "profile-picture",
        "space-details",
        "pagetree",
        "easy-dropdown-menu",
        "spreadsheet-table",
        "multimedia",
        "calendar",
        "create-from-template",
        "last-edited-date",
        "widget",
        "roadmap",
        "easy-dropdown-menu-predefined",
        "viewxls",
        "viewdoc",
        "contentbylabel",
        "pivot-table",
        "todo",
        "viewppt",
        "adhocboard"
    };

    public void Process(HtmlNode macroNode, ConversionContext context)
    {
        // Dynamic content macros generate content at view time from Confluence's database.
        // In a static Markdown export, this content is not available.
        // Remove silently - these are navigation/discovery widgets, not page content.
        macroNode.ParentNode.RemoveChild(macroNode);
    }
}
