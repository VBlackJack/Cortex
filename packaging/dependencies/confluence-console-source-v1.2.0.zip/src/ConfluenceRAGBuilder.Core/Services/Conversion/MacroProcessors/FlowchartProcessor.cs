// Author: Julien Bombled
// License: Apache 2.0

using System.Collections.Generic;
using System.Linq;
using HtmlAgilityPack;

namespace ConfluenceRAGBuilder.Services.Conversion.MacroProcessors;

internal sealed class FlowchartProcessor : IMacroProcessor
{
    public IReadOnlyList<string> SupportedMacroNames => new[] { "flowchart" };

    public void Process(HtmlNode macroNode, ConversionContext context)
    {
        var title = macroNode.Descendants("ac:parameter")
            .FirstOrDefault(n => n.GetAttributeValue("ac:name", "") == "title")
            ?.InnerText ?? "Flowchart";

        // Flowchart macros store diagram data in plain-text-body (not human-readable)
        // Replace with a descriptive placeholder
        var safeTitle = HtmlDocument.HtmlEncode(title);
        var replacement = HtmlNode.CreateNode($"<p><em>[{safeTitle}]</em></p>");
        macroNode.ParentNode.ReplaceChild(replacement, macroNode);
    }
}
