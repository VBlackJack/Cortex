// Author: Julien Bombled
// License: Apache 2.0

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using ConfluenceRAGBuilder.Services.Conversion.MacroProcessors;
using HtmlAgilityPack;
using ReverseMarkdown;

namespace ConfluenceRAGBuilder.Services.Conversion;

/// <summary>
/// Converts Confluence storage-format HTML into a Markdown body without frontmatter.
/// </summary>
public sealed class HtmlToMarkdownConverter : IHtmlToMarkdownConverter
{
    private readonly IEnumerable<IMacroProcessor> _processors;
    private readonly Converter _markdownConverter;
    private readonly Dictionary<string, IMacroProcessor> _processorMap = new(StringComparer.OrdinalIgnoreCase);
    private readonly IMacroProcessor? _fallbackProcessor;

    /// <summary>
    /// Initializes the converter with the canonical macro-processing pipeline.
    /// </summary>
    public HtmlToMarkdownConverter()
        : this(CreateDefaultProcessors())
    {
    }

    internal HtmlToMarkdownConverter(IEnumerable<IMacroProcessor> processors)
    {
        _processors = processors;

        foreach (var p in _processors)
        {
            if (p.SupportedMacroNames.Contains("*"))
            {
                _fallbackProcessor = p;
            }
            foreach (var name in p.SupportedMacroNames)
            {
                _processorMap[name] = p;
            }
        }

        var config = new Config
        {
            GithubFlavored = true,
            RemoveComments = true,
            SmartHrefHandling = true,
            UnknownTags = Config.UnknownTagsOption.Bypass
        };
        _markdownConverter = new Converter(config);
    }

    /// <inheritdoc />
    public ConversionResult Convert(string htmlStorageFormat, ConversionContext context)
    {
        var result = new ConversionResult();

        if (string.IsNullOrWhiteSpace(htmlStorageFormat))
        {
            return result;
        }

        var doc = new HtmlDocument();
        doc.LoadHtml(htmlStorageFormat);

        // 1. Remove style and script tags
        var scriptsAndStyles = doc.DocumentNode.Descendants().Where(n => n.Name == "script" || n.Name == "style").ToList();
        if (scriptsAndStyles.Any())
        {
            foreach (var node in scriptsAndStyles)
            {
                node.Remove();
            }
        }

        // 2. Pre-process macros and specific tags
        // Collect all nodes that need processing
        var nodesToProcess = doc.DocumentNode.Descendants()
            .Where(n => new[] { "ac:structured-macro", "ac:link", "ac:image", "ac:task-list", "ac:emoticon", "table" }.Contains(n.Name))
            .OrderByDescending(n => n.Ancestors().Count())
            .ToList();

        if (nodesToProcess.Any())
        {
            foreach (var node in nodesToProcess)
            {
                // Skip nodes that have been detached from the document by a previous processor
                bool isDetached = true;
                var curr = node;
                while (curr != null)
                {
                    if (curr == doc.DocumentNode)
                    {
                        isDetached = false;
                        break;
                    }
                    curr = curr.ParentNode;
                }

                if (isDetached)
                {
                    continue;
                }

                string key;
                if (node.Name == "ac:structured-macro")
                {
                    key = node.GetAttributeValue("ac:name", "");
                }
                else
                {
                    key = node.Name;
                }

                if (_processorMap.TryGetValue(key, out var processor))
                {
                    processor.Process(node, context);
                }
                else if (node.Name == "ac:structured-macro" && _fallbackProcessor != null)
                {
                    _fallbackProcessor.Process(node, context);
                }
            }
        }

        // 3. Convert to Markdown
        var cleanHtml = doc.DocumentNode.OuterHtml;
        var markdown = _markdownConverter.Convert(cleanHtml);

        // 4. Post-process Markdown
        markdown = PostProcessMarkdown(markdown);

        // 5. Calculate statistics
        result.Markdown = markdown;
        result.Warnings = context.Warnings;
        result.HasCodeBlocks = markdown.Contains("```");
        result.HasTables = markdown.Contains("|---|") || markdown.Contains("| --- |") || markdown.Contains("|---|---|");
        result.WordCount = CountWords(markdown);

        return result;
    }

    private string PostProcessMarkdown(string markdown)
    {
        if (string.IsNullOrEmpty(markdown)) return markdown;

        // Normalize line endings
        markdown = markdown.Replace("\r\n", "\n").Replace("\r", "\n");

        // Remove trailing spaces on lines
        markdown = Regex.Replace(markdown, @"[ \t]+$", "", RegexOptions.Multiline);

        // Max 2 consecutive empty lines -> 1 empty line
        markdown = Regex.Replace(markdown, @"\n{3,}", "\n\n");

        // ReverseMarkdown 5 emits empty blockquote lines around panel paragraphs.
        markdown = Regex.Replace(markdown, @"(?m)^>\s*$\n", "");

        // Clean up unnecessary escapes by ReverseMarkdown (e.g., \* or \_)
        // Only do this if they are not part of an actual escape sequence that's needed.
        // ReverseMarkdown sometimes escapes brackets inside normal text.
        markdown = markdown.Replace(@"\[", "[").Replace(@"\]", "]").Replace(@"\_", "_").Replace(@"\*", "*");

        return markdown.Trim();
    }

    private int CountWords(string text)
    {
        if (string.IsNullOrWhiteSpace(text)) return 0;

        // Simple word count, could be improved
        var matches = Regex.Matches(text, @"\b[\w-]+\b");
        return matches.Count;
    }

    private static IReadOnlyList<IMacroProcessor> CreateDefaultProcessors()
    {
        return
        [
            new CodeBlockProcessor(),
            new PanelProcessor(),
            new ExpandProcessor(),
            new StatusProcessor(),
            new BodyMacroProcessor(),
            new LinkProcessor(),
            new ImageProcessor(),
            new TableProcessor(),
            new TaskListProcessor(),
            new EmoticonProcessor(),
            new ChildrenMacroProcessor(),
            new TocProcessor(),
            new MarkdownMacroProcessor(),
            new ViewFileProcessor(),
            new DrawIoProcessor(),
            new UiButtonProcessor(),
            new FlowchartProcessor(),
            new JiraProcessor(),
            new ExcerptProcessor(),
            new IncludeProcessor(),
            new AnchorProcessor(),
            new QuoteProcessor(),
            new HtmlMacroProcessor(),
            new GliffyProcessor(),
            new DynamicContentProcessor(),
            new FallbackProcessor()
        ];
    }
}
