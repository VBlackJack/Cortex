// Author: Julien Bombled
// License: Apache 2.0

using System.Collections.Generic;
using ConfluenceRAGBuilder.Models;

namespace ConfluenceRAGBuilder.Services.Conversion;

/// <summary>
/// Carries page metadata, attachments, and warnings through one conversion.
/// </summary>
public sealed class ConversionContext
{
    /// <summary>Gets or sets the stable source page identifier.</summary>
    public string PageId { get; set; } = string.Empty;
    /// <summary>Gets or sets the source page title.</summary>
    public string PageTitle { get; set; } = string.Empty;
    /// <summary>Gets or sets the Confluence space key.</summary>
    public string SpaceKey { get; set; } = string.Empty;
    /// <summary>Gets or sets the local attachments available to macro processors.</summary>
    public List<AttachmentInfo> Attachments { get; set; } = new();
    /// <summary>Gets or sets the warnings collected during conversion.</summary>
    public List<ConversionWarning> Warnings { get; set; } = new();
    /// <summary>Gets or sets the Markdown-relative attachment path prefix.</summary>
    public string AttachmentsRelativePath { get; set; } = string.Empty;
}

/// <summary>
/// Describes a non-fatal macro conversion issue.
/// </summary>
public sealed class ConversionWarning
{
    /// <summary>Gets or sets the affected macro name.</summary>
    public string MacroName { get; set; } = string.Empty;
    /// <summary>Gets or sets the human-readable warning.</summary>
    public string Message { get; set; } = string.Empty;
    /// <summary>Gets or sets a bounded source context for diagnosis.</summary>
    public string Context { get; set; } = string.Empty;
}

/// <summary>
/// Contains the converted Markdown body and its derived statistics.
/// </summary>
public sealed class ConversionResult
{
    /// <summary>Gets or sets the Markdown body without frontmatter.</summary>
    public string Markdown { get; set; } = string.Empty;
    /// <summary>Gets or sets non-fatal warnings emitted by macro processors.</summary>
    public List<ConversionWarning> Warnings { get; set; } = new();
    /// <summary>Gets or sets the approximate word count.</summary>
    public int WordCount { get; set; }
    /// <summary>Gets or sets whether fenced code blocks were detected.</summary>
    public bool HasCodeBlocks { get; set; }
    /// <summary>Gets or sets whether Markdown tables were detected.</summary>
    public bool HasTables { get; set; }
}
