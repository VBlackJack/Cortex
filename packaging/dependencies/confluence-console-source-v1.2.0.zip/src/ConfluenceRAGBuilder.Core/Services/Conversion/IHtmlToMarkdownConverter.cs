// Author: Julien Bombled
// License: Apache 2.0

namespace ConfluenceRAGBuilder.Services.Conversion;

/// <summary>
/// Defines deterministic conversion from Confluence storage-format HTML to Markdown.
/// </summary>
public interface IHtmlToMarkdownConverter
{
    /// <summary>
    /// Converts one page body while collecting conversion warnings and statistics.
    /// </summary>
    /// <param name="htmlStorageFormat">The Confluence storage-format HTML or XHTML.</param>
    /// <param name="context">Page metadata and local attachment context.</param>
    /// <returns>The Markdown body and conversion metadata.</returns>
    ConversionResult Convert(string htmlStorageFormat, ConversionContext context);
}
