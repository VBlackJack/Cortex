using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using ConfluenceRAGBuilder.Models;

namespace ConfluenceRAGBuilder.Services.Export
{
    /// <summary>
    /// Preserves the existing deterministic H2 splitting behavior for all hosts.
    /// </summary>
    public sealed class SmartSplitterService : ISmartSplitterService
    {
        /// <inheritdoc />
        public SplitResult Split(string markdown, string baseFileName, string pageTitle, SplitOptions options)
        {
            if (string.IsNullOrWhiteSpace(markdown))
            {
                return new SplitResult
                {
                    IsSplit = false,
                    Parts = new List<SplitPart> { new SplitPart { Content = markdown ?? string.Empty, FileName = baseFileName + ".md", Title = pageTitle, IsParent = true } }
                };
            }

            int totalWords = CountWords(markdown);
            if (totalWords <= options.ThresholdWordCount)
            {
                return new SplitResult
                {
                    IsSplit = false,
                    Parts = new List<SplitPart> { new SplitPart { Content = markdown, FileName = baseFileName + ".md", Title = pageTitle, IsParent = true } }
                };
            }

            var sections = ParseSections(markdown);

            if (sections.Count(s => s.IsH2) < 2)
            {
                return new SplitResult
                {
                    IsSplit = false,
                    Parts = new List<SplitPart> { new SplitPart { Content = markdown, FileName = baseFileName + ".md", Title = pageTitle, IsParent = true } }
                };
            }

            var mergedSections = MergeSmallSections(sections, options.MinSectionWordCount);

            if (mergedSections.Count(s => s.IsH2) < 2)
            {
                return new SplitResult
                {
                    IsSplit = false,
                    Parts = new List<SplitPart> { new SplitPart { Content = markdown, FileName = baseFileName + ".md", Title = pageTitle, IsParent = true } }
                };
            }

            var result = new SplitResult { IsSplit = true, Parts = new List<SplitPart>() };

            var introSection = mergedSections.FirstOrDefault(s => !s.IsH2);
            string introContent = introSection?.Content ?? string.Empty;

            var childSections = mergedSections.Where(s => s.IsH2).ToList();
            var tocBuilder = new StringBuilder();
            tocBuilder.AppendLine();
            tocBuilder.AppendLine("## Table of Contents");

            int index = 0;
            var childParts = new List<SplitPart>();

            foreach (var section in childSections)
            {
                string letter = GetLetter(index);
                string sanitizedTitle = SanitizeTitle(section.Title);
                string fileName = $"{baseFileName}{letter}__{sanitizedTitle}.md";

                tocBuilder.AppendLine($"* [{section.Title}](./{fileName})");

                childParts.Add(new SplitPart
                {
                    Content = $"## {section.Title}\n{section.Content}".Trim(),
                    FileName = fileName,
                    Title = section.Title,
                    IsParent = false
                });

                index++;
            }

            string parentContent = introContent.TrimEnd() + "\n" + tocBuilder.ToString();

            result.Parts.Add(new SplitPart
            {
                Content = parentContent.Trim(),
                FileName = baseFileName + ".md",
                Title = pageTitle,
                IsParent = true
            });

            result.Parts.AddRange(childParts);

            return result;
        }

        private int CountWords(string text)
        {
            if (string.IsNullOrWhiteSpace(text)) return 0;
            return text.Split(new[] { ' ', '\r', '\n', '\t' }, StringSplitOptions.RemoveEmptyEntries).Length;
        }

        private class RawSection
        {
            public string Title { get; set; } = string.Empty;
            public string Content { get; set; } = string.Empty;
            public bool IsH2 { get; set; }
            public int WordCount { get; set; }
        }

        private List<RawSection> ParseSections(string markdown)
        {
            var sections = new List<RawSection>();
            var lines = markdown.Split(new[] { "\r\n", "\n" }, StringSplitOptions.None);

            bool inCodeBlock = false;
            RawSection currentSection = new RawSection { Title = "Intro", IsH2 = false, Content = "" };
            var contentBuilder = new StringBuilder();

            foreach (var line in lines)
            {
                if (line.StartsWith("```"))
                {
                    inCodeBlock = !inCodeBlock;
                }

                if (!inCodeBlock && line.StartsWith("## "))
                {
                    currentSection.Content = contentBuilder.ToString();
                    currentSection.WordCount = CountWords(currentSection.Content);
                    sections.Add(currentSection);

                    currentSection = new RawSection
                    {
                        Title = line.Substring(3).Trim(),
                        IsH2 = true,
                        Content = ""
                    };
                    contentBuilder.Clear();
                }
                else
                {
                    contentBuilder.AppendLine(line);
                }
            }

            currentSection.Content = contentBuilder.ToString();
            currentSection.WordCount = CountWords(currentSection.Content);
            sections.Add(currentSection);

            return sections;
        }

        private List<RawSection> MergeSmallSections(List<RawSection> sections, int minWordCount)
        {
            var merged = new List<RawSection>();
            var h2Sections = sections.Where(s => s.IsH2).ToList();
            var introSection = sections.FirstOrDefault(s => !s.IsH2);

            if (introSection != null)
            {
                merged.Add(introSection);
            }

            RawSection? current = null;

            foreach (var sec in h2Sections)
            {
                if (current == null)
                {
                    current = sec;
                }
                else
                {
                    if (current.WordCount < minWordCount)
                    {
                        current.Content += $"\n## {sec.Title}\n{sec.Content}";
                        current.WordCount += sec.WordCount + CountWords(sec.Title) + 1;
                    }
                    else
                    {
                        merged.Add(current);
                        current = sec;
                    }
                }
            }

            if (current != null)
            {
                if (current.WordCount < minWordCount && merged.Count > (introSection != null ? 1 : 0))
                {
                    var last = merged.Last();
                    last.Content += $"\n## {current.Title}\n{current.Content}";
                    last.WordCount += current.WordCount + CountWords(current.Title) + 1;
                }
                else
                {
                    merged.Add(current);
                }
            }

            return merged;
        }

        private string GetLetter(int index)
        {
            string result = "";
            while (index >= 0)
            {
                result = (char)('a' + (index % 26)) + result;
                index = (index / 26) - 1;
            }
            return result;
        }

        private string SanitizeTitle(string title)
        {
            var result = Regex.Replace((title ?? "").ToLowerInvariant(), @"[^a-z0-9]+", "-").Trim('-');
            if (result.Length > 50) result = result.Substring(0, 50).Trim('-');
            return string.IsNullOrEmpty(result) ? "section" : result;
        }
    }
}
