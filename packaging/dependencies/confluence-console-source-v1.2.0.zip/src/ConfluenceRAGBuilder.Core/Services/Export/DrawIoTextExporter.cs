using System;
using System.Buffers.Binary;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;
using ConfluenceRAGBuilder.Helpers;
using ConfluenceRAGBuilder.Models;

namespace ConfluenceRAGBuilder.Services.Export;

/// <summary>
/// Extracts searchable text from draw.io XML or PNG attachments.
/// </summary>
public static class DrawIoTextExporter
{
    private static readonly byte[] PngSignature = { 137, 80, 78, 71, 13, 10, 26, 10 };

    /// <summary>
    /// Writes a readable Markdown companion next to a local draw.io attachment when possible.
    /// </summary>
    /// <returns>The companion path, or <see langword="null"/> when no draw.io content exists.</returns>
    public static async Task<string?> ExportReadableMarkdownAsync(AttachmentInfo attachment, CancellationToken cancellationToken = default)
    {
        if (!(DrawIoFileHelper.IsDrawIoExtractionCandidate(attachment.FileName) || attachment.IsDrawIoSourceCandidate)
            || string.IsNullOrWhiteSpace(attachment.LocalPath)
            || !File.Exists(attachment.LocalPath))
        {
            return null;
        }

        var rawContent = await TryReadDrawIoContentAsync(attachment.LocalPath, attachment.FileName, cancellationToken);
        if (string.IsNullOrWhiteSpace(rawContent))
        {
            return null;
        }

        var markdown = BuildReadableMarkdown(attachment.FileName, rawContent);
        var outputFileName = string.IsNullOrWhiteSpace(attachment.OutputFileName)
            ? attachment.FileName
            : attachment.OutputFileName;
        var targetPath = Path.Combine(
            Path.GetDirectoryName(attachment.LocalPath) ?? string.Empty,
            DrawIoFileHelper.ToReadableMarkdownFileName(outputFileName));

        await File.WriteAllTextAsync(targetPath, markdown, cancellationToken);
        attachment.DrawIoTextPath = targetPath;
        return targetPath;
    }

    private static async Task<string?> TryReadDrawIoContentAsync(string localPath, string fileName, CancellationToken cancellationToken)
    {
        if (DrawIoFileHelper.IsDrawIoXmlFileName(fileName) || attachmentFileIsExplicitDrawIoSource(fileName))
        {
            return await File.ReadAllTextAsync(localPath, cancellationToken);
        }

        if (DrawIoFileHelper.IsPngFileName(fileName))
        {
            return await TryExtractDrawIoContentFromPngAsync(localPath, cancellationToken);
        }

        return null;
    }

    private static bool attachmentFileIsExplicitDrawIoSource(string fileName)
    {
        return !DrawIoFileHelper.IsPngFileName(fileName);
    }

    private static async Task<string?> TryExtractDrawIoContentFromPngAsync(string localPath, CancellationToken cancellationToken)
    {
        await using var stream = new FileStream(localPath, FileMode.Open, FileAccess.Read, FileShare.Read, 8192, true);
        if (stream.Length < PngSignature.Length)
        {
            return null;
        }

        var signature = new byte[PngSignature.Length];
        await stream.ReadExactlyAsync(signature, cancellationToken);
        if (!signature.SequenceEqual(PngSignature))
        {
            return null;
        }

        var header = new byte[8];
        while (stream.Position < stream.Length)
        {
            await stream.ReadExactlyAsync(header, cancellationToken);
            var length = BinaryPrimitives.ReadInt32BigEndian(header.AsSpan(0, 4));
            var chunkType = Encoding.ASCII.GetString(header, 4, 4);

            if (length < 0 || length > 64 * 1024 * 1024 || stream.Position + length + 4 > stream.Length)
            {
                return null;
            }

            var data = new byte[length];
            if (length > 0)
            {
                await stream.ReadExactlyAsync(data, cancellationToken);
            }

            stream.Position += 4; // CRC

            var drawIoContent = TryExtractDrawIoTextChunk(chunkType, data);
            if (!string.IsNullOrWhiteSpace(drawIoContent))
            {
                return drawIoContent;
            }

            if (chunkType == "IEND")
            {
                return null;
            }
        }

        return null;
    }

    private static string? TryExtractDrawIoTextChunk(string chunkType, byte[] data)
    {
        return chunkType switch
        {
            "tEXt" => TryExtractTextChunk(data),
            "zTXt" => TryExtractCompressedTextChunk(data),
            "iTXt" => TryExtractInternationalTextChunk(data),
            _ => null
        };
    }

    private static string? TryExtractTextChunk(byte[] data)
    {
        var separatorIndex = Array.IndexOf(data, (byte)0);
        if (separatorIndex < 0)
        {
            return null;
        }

        var keyword = Encoding.UTF8.GetString(data, 0, separatorIndex);
        var text = Encoding.UTF8.GetString(data, separatorIndex + 1, data.Length - separatorIndex - 1);
        return TryNormalizeDrawIoText(keyword, text);
    }

    private static string? TryExtractCompressedTextChunk(byte[] data)
    {
        var separatorIndex = Array.IndexOf(data, (byte)0);
        if (separatorIndex < 0 || separatorIndex + 1 >= data.Length)
        {
            return null;
        }

        var keyword = Encoding.UTF8.GetString(data, 0, separatorIndex);
        var compressionMethod = data[separatorIndex + 1];
        if (compressionMethod != 0)
        {
            return null;
        }

        var compressed = data.Skip(separatorIndex + 2).ToArray();
        var text = TryInflate(compressed, useZlibStream: true) ?? TryInflate(compressed, useZlibStream: false);
        return TryNormalizeDrawIoText(keyword, text);
    }

    private static string? TryExtractInternationalTextChunk(byte[] data)
    {
        var keywordEnd = Array.IndexOf(data, (byte)0);
        if (keywordEnd < 0 || keywordEnd + 2 >= data.Length)
        {
            return null;
        }

        var keyword = Encoding.UTF8.GetString(data, 0, keywordEnd);
        var compressed = data[keywordEnd + 1] == 1;
        var compressionMethod = data[keywordEnd + 2];
        var index = keywordEnd + 3;

        var languageEnd = Array.IndexOf(data, (byte)0, index);
        if (languageEnd < 0)
        {
            return null;
        }

        index = languageEnd + 1;
        var translatedKeywordEnd = Array.IndexOf(data, (byte)0, index);
        if (translatedKeywordEnd < 0)
        {
            return null;
        }

        index = translatedKeywordEnd + 1;
        var textBytes = data.Skip(index).ToArray();
        var text = compressed && compressionMethod == 0
            ? TryInflate(textBytes, useZlibStream: true) ?? TryInflate(textBytes, useZlibStream: false)
            : Encoding.UTF8.GetString(textBytes);

        return TryNormalizeDrawIoText(keyword, text);
    }

    private static string? TryNormalizeDrawIoText(string keyword, string? text)
    {
        if (string.IsNullOrWhiteSpace(text))
        {
            return null;
        }

        var normalized = WebUtility.UrlDecode(text).Trim();
        if (!keyword.Contains("mxfile", StringComparison.OrdinalIgnoreCase)
            && !normalized.Contains("<mxfile", StringComparison.OrdinalIgnoreCase))
        {
            return null;
        }

        var mxfileStart = normalized.IndexOf("<mxfile", StringComparison.OrdinalIgnoreCase);
        if (mxfileStart < 0)
        {
            return normalized;
        }

        var mxfileEnd = normalized.IndexOf("</mxfile>", mxfileStart, StringComparison.OrdinalIgnoreCase);
        return mxfileEnd < 0
            ? normalized[mxfileStart..]
            : normalized.Substring(mxfileStart, mxfileEnd - mxfileStart + "</mxfile>".Length);
    }

    /// <summary>
    /// Converts draw.io XML content into a readable Markdown summary.
    /// </summary>
    /// <param name="fileName">The source diagram file name.</param>
    /// <param name="drawIoContent">The decoded draw.io XML content.</param>
    /// <returns>A Markdown body containing the extracted diagram text.</returns>
    public static string BuildReadableMarkdown(string fileName, string drawIoContent)
    {
        var diagrams = ExtractDiagrams(drawIoContent).ToList();
        var sb = new StringBuilder();

        sb.AppendLine($"# Diagramme draw.io - {fileName}");
        sb.AppendLine();
        sb.AppendLine($"Fichier source: `{fileName}`");
        sb.AppendLine();

        if (diagrams.Count == 0)
        {
            sb.AppendLine("## Source draw.io");
            AppendCodeBlock(sb, "xml", drawIoContent);
            return sb.ToString();
        }

        foreach (var diagram in diagrams)
        {
            sb.AppendLine($"## {diagram.Name}");
            sb.AppendLine();

            if (diagram.Labels.Count > 0)
            {
                sb.AppendLine("### Textes extraits");
                foreach (var label in diagram.Labels)
                {
                    sb.AppendLine($"- {label}");
                }
                sb.AppendLine();
            }

            if (!string.IsNullOrWhiteSpace(diagram.Xml))
            {
                sb.AppendLine("### XML draw.io");
                AppendCodeBlock(sb, "xml", diagram.Xml);
            }
            else
            {
                sb.AppendLine("_Le contenu du diagramme est compresse et n'a pas pu etre decode._");
                sb.AppendLine();
            }
        }

        return sb.ToString();
    }

    private static IEnumerable<DrawIoDiagram> ExtractDiagrams(string drawIoContent)
    {
        if (string.IsNullOrWhiteSpace(drawIoContent))
        {
            yield break;
        }

        if (!TryParseXml(drawIoContent, out var document))
        {
            yield break;
        }

        var diagramNodes = document.Descendants().Where(e => e.Name.LocalName == "diagram").ToList();
        if (diagramNodes.Count == 0)
        {
            var graphModel = document.Descendants().FirstOrDefault(e => e.Name.LocalName == "mxGraphModel");
            if (graphModel != null)
            {
                var xml = graphModel.ToString(SaveOptions.DisableFormatting);
                yield return new DrawIoDiagram("Diagramme", xml, ExtractLabels(xml));
            }
            yield break;
        }

        foreach (var diagramNode in diagramNodes)
        {
            var name = diagramNode.Attribute("name")?.Value;
            if (string.IsNullOrWhiteSpace(name))
            {
                name = "Diagramme";
            }

            var graphModel = diagramNode.Elements().FirstOrDefault(e => e.Name.LocalName == "mxGraphModel");
            var diagramXml = graphModel?.ToString(SaveOptions.DisableFormatting)
                ?? TryDecodeCompressedDiagram(diagramNode.Value.Trim())
                ?? string.Empty;

            yield return new DrawIoDiagram(name, diagramXml, ExtractLabels(diagramXml));
        }
    }

    private static IReadOnlyList<string> ExtractLabels(string diagramXml)
    {
        if (!TryParseXml(diagramXml, out var document))
        {
            return Array.Empty<string>();
        }

        return document.Descendants()
            .SelectMany(e => new[]
            {
                e.Attribute("value")?.Value,
                e.Attribute("label")?.Value
            })
            .Where(v => !string.IsNullOrWhiteSpace(v))
            .Select(v => CleanLabel(v!))
            .Where(v => !string.IsNullOrWhiteSpace(v))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();
    }

    private static string? TryDecodeCompressedDiagram(string encodedDiagram)
    {
        if (string.IsNullOrWhiteSpace(encodedDiagram))
        {
            return null;
        }

        try
        {
            var bytes = Convert.FromBase64String(encodedDiagram);
            return TryInflate(bytes, useZlibStream: true)
                ?? TryInflate(bytes, useZlibStream: false)
                ?? TryInflate(bytes.Skip(2).ToArray(), useZlibStream: false);
        }
        catch
        {
            return null;
        }
    }

    private static string? TryInflate(byte[] bytes, bool useZlibStream)
    {
        try
        {
            using var input = new MemoryStream(bytes);
            using var output = new MemoryStream();
            using Stream inflater = useZlibStream
                ? new ZLibStream(input, CompressionMode.Decompress)
                : new DeflateStream(input, CompressionMode.Decompress);

            inflater.CopyTo(output);
            var inflated = Encoding.UTF8.GetString(output.ToArray());
            return WebUtility.UrlDecode(inflated);
        }
        catch
        {
            return null;
        }
    }

    private static bool TryParseXml(string xml, out XDocument document)
    {
        try
        {
            document = XDocument.Parse(xml, LoadOptions.PreserveWhitespace);
            return true;
        }
        catch
        {
            document = new XDocument();
            return false;
        }
    }

    private static string CleanLabel(string label)
    {
        var cleaned = WebUtility.HtmlDecode(label);
        cleaned = Regex.Replace(cleaned, @"<br\s*/?>", " ", RegexOptions.IgnoreCase);
        cleaned = Regex.Replace(cleaned, "<.*?>", " ");
        cleaned = Regex.Replace(cleaned, @"\s+", " ");
        return cleaned.Trim();
    }

    private static void AppendCodeBlock(StringBuilder sb, string language, string content)
    {
        sb.AppendLine($"```{language}");
        sb.AppendLine((content ?? string.Empty).Replace("```", "'''").Trim());
        sb.AppendLine("```");
        sb.AppendLine();
    }

    private sealed record DrawIoDiagram(string Name, string Xml, IReadOnlyList<string> Labels);
}
