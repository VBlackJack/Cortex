using ConfluenceRAGBuilder.Models;

namespace ConfluenceRAGBuilder.Services.Export
{
    /// <summary>
    /// Defines stable H2-based splitting for converted Markdown bodies.
    /// </summary>
    public interface ISmartSplitterService
    {
        /// <summary>
        /// Splits a Markdown body when its configured word threshold is exceeded.
        /// </summary>
        /// <returns>The ordered parent and child Markdown parts.</returns>
        SplitResult Split(string markdown, string baseFileName, string pageTitle, SplitOptions options);
    }
}
