using System.Collections.Generic;

namespace ConfluenceRAGBuilder.Models
{
    /// <summary>
    /// Controls H2-based splitting without changing Markdown content semantics.
    /// </summary>
    public sealed class SplitOptions
    {
        /// <summary>Gets or sets the page word-count threshold that enables splitting.</summary>
        public int ThresholdWordCount { get; set; } = 2000;
        /// <summary>Gets or sets the minimum H2 section size before adjacent merging.</summary>
        public int MinSectionWordCount { get; set; } = 200;
    }

    /// <summary>
    /// Represents one Markdown file produced by H2 splitting.
    /// </summary>
    public sealed class SplitPart
    {
        /// <summary>Gets or sets the Markdown body.</summary>
        public string Content { get; set; } = string.Empty;
        /// <summary>Gets or sets the output file name.</summary>
        public string FileName { get; set; } = string.Empty;
        /// <summary>Gets or sets the logical section title.</summary>
        public string Title { get; set; } = string.Empty;
        /// <summary>Gets or sets whether this is the parent page file.</summary>
        public bool IsParent { get; set; }
    }

    /// <summary>
    /// Contains the stable ordered list of Markdown files for a page.
    /// </summary>
    public sealed class SplitResult
    {
        /// <summary>Gets or sets whether the page was split into multiple files.</summary>
        public bool IsSplit { get; set; }
        /// <summary>Gets or sets the ordered output parts.</summary>
        public List<SplitPart> Parts { get; set; } = new List<SplitPart>();
    }
}
