// Author: Julien Bombled
// License: Apache 2.0

using System;

namespace ConfluenceRAGBuilder.Models;

/// <summary>
/// Describes a source attachment and its local conversion state.
/// </summary>
public sealed class AttachmentInfo
{
    /// <summary>Gets or sets the stable attachment identifier.</summary>
    public string Id { get; set; } = string.Empty;
    /// <summary>Gets or sets the original file name.</summary>
    public string FileName { get; set; } = string.Empty;
    /// <summary>Gets or sets the Windows-safe file name written by the console.</summary>
    public string OutputFileName { get; set; } = string.Empty;
    /// <summary>Gets or sets the declared media type.</summary>
    public string MediaType { get; set; } = string.Empty;
    /// <summary>Gets or sets the file size in bytes.</summary>
    public long FileSize { get; set; }
    /// <summary>Gets or sets the source download URL when used by the WPF crawler.</summary>
    public string DownloadUrl { get; set; } = string.Empty;
    /// <summary>Gets or sets the absolute local file path during conversion.</summary>
    public string LocalPath { get; set; } = string.Empty;
    /// <summary>Gets or sets the generated readable draw.io Markdown path.</summary>
    public string DrawIoTextPath { get; set; } = string.Empty;
    /// <summary>Gets or sets whether the attachment was identified as a draw.io source.</summary>
    public bool IsDrawIoSourceCandidate { get; set; }
    /// <summary>Gets or sets the owning page identifier.</summary>
    public string PageId { get; set; } = string.Empty;
    /// <summary>Gets or sets whether the attachment is available locally.</summary>
    public bool Downloaded { get; set; }
}
