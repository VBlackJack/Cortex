// Licensed under the Apache License, Version 2.0.
// Copyright 2026 Julien Bombled

using System.Globalization;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace ConfluenceRAGBuilder.ConsoleHost.Tests;

internal sealed class JsonSchemaTestValidator : IDisposable
{
    private readonly JsonDocument _schemaDocument;

    internal JsonSchemaTestValidator(string schemaPath)
    {
        _schemaDocument = JsonDocument.Parse(File.ReadAllText(schemaPath));
    }

    internal void Validate(JsonElement instance)
    {
        List<string> errors = [];
        ValidateNode(instance, _schemaDocument.RootElement, "$", errors);
        Assert.True(errors.Count == 0, string.Join(Environment.NewLine, errors));
    }

    public void Dispose()
    {
        _schemaDocument.Dispose();
    }

    private void ValidateNode(
        JsonElement instance,
        JsonElement schema,
        string path,
        List<string> errors)
    {
        if (schema.TryGetProperty("$ref", out JsonElement reference))
        {
            ValidateNode(instance, ResolveReference(reference.GetString()!), path, errors);
        }

        ValidateType(instance, schema, path, errors);
        ValidateConstAndEnum(instance, schema, path, errors);
        ValidateObject(instance, schema, path, errors);
        ValidateArray(instance, schema, path, errors);
        ValidateString(instance, schema, path, errors);
        ValidateNumber(instance, schema, path, errors);
        ValidateCompositions(instance, schema, path, errors);
    }

    private static void ValidateType(
        JsonElement instance,
        JsonElement schema,
        string path,
        List<string> errors)
    {
        if (!schema.TryGetProperty("type", out JsonElement typeElement))
        {
            return;
        }

        string type = typeElement.GetString()!;
        bool matches = type switch
        {
            "object" => instance.ValueKind == JsonValueKind.Object,
            "array" => instance.ValueKind == JsonValueKind.Array,
            "string" => instance.ValueKind == JsonValueKind.String,
            "integer" => instance.ValueKind == JsonValueKind.Number && instance.TryGetInt64(out _),
            "number" => instance.ValueKind == JsonValueKind.Number,
            "boolean" => instance.ValueKind is JsonValueKind.True or JsonValueKind.False,
            "null" => instance.ValueKind == JsonValueKind.Null,
            _ => throw new InvalidDataException($"Unsupported test schema type: {type}")
        };

        if (!matches)
        {
            errors.Add($"{path}: expected {type}, found {instance.ValueKind}.");
        }
    }

    private static void ValidateConstAndEnum(
        JsonElement instance,
        JsonElement schema,
        string path,
        List<string> errors)
    {
        if (schema.TryGetProperty("const", out JsonElement constant)
            && !JsonElement.DeepEquals(instance, constant))
        {
            errors.Add($"{path}: value does not match const.");
        }

        if (schema.TryGetProperty("enum", out JsonElement enumValues)
            && !enumValues.EnumerateArray().Any(value => JsonElement.DeepEquals(instance, value)))
        {
            errors.Add($"{path}: value is not in enum.");
        }
    }

    private void ValidateObject(
        JsonElement instance,
        JsonElement schema,
        string path,
        List<string> errors)
    {
        if (instance.ValueKind != JsonValueKind.Object)
        {
            return;
        }

        if (schema.TryGetProperty("required", out JsonElement required))
        {
            foreach (JsonElement requiredName in required.EnumerateArray())
            {
                string name = requiredName.GetString()!;
                if (!instance.TryGetProperty(name, out _))
                {
                    errors.Add($"{path}: missing required property '{name}'.");
                }
            }
        }

        if (!schema.TryGetProperty("properties", out JsonElement properties))
        {
            return;
        }

        foreach (JsonProperty property in instance.EnumerateObject())
        {
            if (properties.TryGetProperty(property.Name, out JsonElement propertySchema))
            {
                ValidateNode(property.Value, propertySchema, $"{path}.{property.Name}", errors);
            }
            else if (schema.TryGetProperty("additionalProperties", out JsonElement additional)
                && additional.ValueKind == JsonValueKind.False)
            {
                errors.Add($"{path}: unexpected property '{property.Name}'.");
            }
        }
    }

    private void ValidateArray(
        JsonElement instance,
        JsonElement schema,
        string path,
        List<string> errors)
    {
        if (instance.ValueKind != JsonValueKind.Array)
        {
            return;
        }

        int length = instance.GetArrayLength();
        if (schema.TryGetProperty("minItems", out JsonElement minimum)
            && length < minimum.GetInt32())
        {
            errors.Add($"{path}: array has fewer than {minimum.GetInt32()} items.");
        }

        if (schema.TryGetProperty("maxItems", out JsonElement maximum)
            && length > maximum.GetInt32())
        {
            errors.Add($"{path}: array has more than {maximum.GetInt32()} items.");
        }

        if (schema.TryGetProperty("items", out JsonElement itemSchema))
        {
            int index = 0;
            foreach (JsonElement item in instance.EnumerateArray())
            {
                ValidateNode(item, itemSchema, $"{path}[{index}]", errors);
                index++;
            }
        }
    }

    private static void ValidateString(
        JsonElement instance,
        JsonElement schema,
        string path,
        List<string> errors)
    {
        if (instance.ValueKind != JsonValueKind.String)
        {
            return;
        }

        string value = instance.GetString()!;
        if (schema.TryGetProperty("minLength", out JsonElement minimum)
            && value.Length < minimum.GetInt32())
        {
            errors.Add($"{path}: string is shorter than {minimum.GetInt32()} characters.");
        }

        if (schema.TryGetProperty("maxLength", out JsonElement maximum)
            && value.Length > maximum.GetInt32())
        {
            errors.Add($"{path}: string is longer than {maximum.GetInt32()} characters.");
        }

        if (schema.TryGetProperty("pattern", out JsonElement pattern)
            && !Regex.IsMatch(value, pattern.GetString()!, RegexOptions.CultureInvariant))
        {
            errors.Add($"{path}: string does not match the required pattern.");
        }

        if (schema.TryGetProperty("format", out JsonElement format))
        {
            ValidateFormat(value, format.GetString()!, path, errors);
        }
    }

    private static void ValidateNumber(
        JsonElement instance,
        JsonElement schema,
        string path,
        List<string> errors)
    {
        if (instance.ValueKind != JsonValueKind.Number)
        {
            return;
        }

        decimal value = instance.GetDecimal();
        if (schema.TryGetProperty("minimum", out JsonElement minimum)
            && value < minimum.GetDecimal())
        {
            errors.Add($"{path}: number is lower than {minimum.GetDecimal()}.");
        }

        if (schema.TryGetProperty("maximum", out JsonElement maximum)
            && value > maximum.GetDecimal())
        {
            errors.Add($"{path}: number is greater than {maximum.GetDecimal()}.");
        }
    }

    private void ValidateCompositions(
        JsonElement instance,
        JsonElement schema,
        string path,
        List<string> errors)
    {
        if (schema.TryGetProperty("allOf", out JsonElement allOf))
        {
            foreach (JsonElement childSchema in allOf.EnumerateArray())
            {
                ValidateNode(instance, childSchema, path, errors);
            }
        }

        if (schema.TryGetProperty("not", out JsonElement notSchema)
            && IsValid(instance, notSchema))
        {
            errors.Add($"{path}: value matches a forbidden schema.");
        }

        if (schema.TryGetProperty("if", out JsonElement ifSchema))
        {
            string branch = IsValid(instance, ifSchema) ? "then" : "else";
            if (schema.TryGetProperty(branch, out JsonElement branchSchema))
            {
                ValidateNode(instance, branchSchema, path, errors);
            }
        }
    }

    private bool IsValid(JsonElement instance, JsonElement schema)
    {
        List<string> errors = [];
        ValidateNode(instance, schema, "$", errors);
        return errors.Count == 0;
    }

    private JsonElement ResolveReference(string reference)
    {
        const string Prefix = "#/";
        if (!reference.StartsWith(Prefix, StringComparison.Ordinal))
        {
            throw new InvalidDataException($"Unsupported test schema reference: {reference}");
        }

        JsonElement current = _schemaDocument.RootElement;
        foreach (string rawSegment in reference[Prefix.Length..].Split('/'))
        {
            string segment = rawSegment.Replace("~1", "/", StringComparison.Ordinal)
                .Replace("~0", "~", StringComparison.Ordinal);
            current = current.GetProperty(segment);
        }

        return current;
    }

    private static void ValidateFormat(
        string value,
        string format,
        string path,
        List<string> errors)
    {
        bool valid = format switch
        {
            "date-time" => DateTimeOffset.TryParse(
                value,
                CultureInfo.InvariantCulture,
                DateTimeStyles.RoundtripKind,
                out _),
            "uri" => Uri.TryCreate(value, UriKind.Absolute, out _),
            _ => throw new InvalidDataException($"Unsupported test schema format: {format}")
        };

        if (!valid)
        {
            errors.Add($"{path}: string is not a valid {format}.");
        }
    }
}
