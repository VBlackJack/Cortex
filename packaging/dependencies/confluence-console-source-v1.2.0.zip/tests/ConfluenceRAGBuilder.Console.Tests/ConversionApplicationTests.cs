// Licensed under the Apache License, Version 2.0.
// Copyright 2026 Julien Bombled

using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;

namespace ConfluenceRAGBuilder.ConsoleHost.Tests;

public sealed class ConversionApplicationTests
{
    private static readonly UTF8Encoding Utf8WithoutBom = new(false);

    [Fact]
    public async Task ProbeReturnsExactMachineReadableCapabilityWithoutUsingAWorkspace()
    {
        StringWriter output = new();
        TextWriter original = System.Console.Out;
        try
        {
            System.Console.SetOut(output);

            int exitCode = await ConversionApplication.RunAsync(
                [ConversionApplication.ProbeArgument],
                CancellationToken.None);

            Assert.Equal(ConversionApplication.SuccessExitCode, exitCode);
        }
        finally
        {
            System.Console.SetOut(original);
        }

        using JsonDocument probe = JsonDocument.Parse(output.ToString());
        Assert.Equal("1.2.0", probe.RootElement.GetProperty("tool_version").GetString());
        Assert.Equal(1, probe.RootElement.GetProperty("schema_version").GetInt32());
        Assert.Equal(2, probe.RootElement.EnumerateObject().Count());
    }

    [Fact]
    public async Task VersionReturnsTheReleaseVersion()
    {
        StringWriter output = new();
        TextWriter original = System.Console.Out;
        try
        {
            System.Console.SetOut(output);

            int exitCode = await ConversionApplication.RunAsync(
                [ConversionApplication.VersionArgument],
                CancellationToken.None);

            Assert.Equal(ConversionApplication.SuccessExitCode, exitCode);
        }
        finally
        {
            System.Console.SetOut(original);
        }

        Assert.Equal("1.2.0", output.ToString().Trim());
    }

    [Theory]
    [InlineData("nominal")]
    [InlineData("partial-failure")]
    [InlineData("attachment-output-sanitization")]
    public void CanonicalJobFixtureMatchesPublishedSchema(string fixtureName)
    {
        using JsonDocument job = JsonDocument.Parse(File.ReadAllText(FixturePath(fixtureName, "job.json")));
        using JsonSchemaTestValidator validator = new(ContractPath("job.schema.json"));

        validator.Validate(job.RootElement);
    }

    [Fact]
    public void PublishedSchemasUseDraft202012()
    {
        foreach (string schemaName in new[] { "job.schema.json", "result.schema.json" })
        {
            using JsonDocument schema = JsonDocument.Parse(File.ReadAllText(ContractPath(schemaName)));
            Assert.Equal(
                "https://json-schema.org/draft/2020-12/schema",
                schema.RootElement.GetProperty("$schema").GetString());
        }
    }

    [Fact]
    public async Task NominalFixtureReturnsZeroAndWritesSchemaValidUtf8LfBodies()
    {
        using TestWorkspace workspace = TestWorkspace.FromFixture("nominal");

        int exitCode = await ConversionApplication.RunAsync(
            new[] { workspace.Path },
            CancellationToken.None);

        Assert.Equal(ConversionApplication.SuccessExitCode, exitCode);
        string resultPath = System.IO.Path.Combine(workspace.Path, "result.json");
        ValidateResult(resultPath);
        byte[] resultBytes = await File.ReadAllBytesAsync(resultPath);
        string resultText = StrictDecode(resultBytes);
        Assert.False(resultBytes.AsSpan().StartsWith(Encoding.UTF8.Preamble));
        Assert.DoesNotContain('\r', resultText);

        using JsonDocument result = JsonDocument.Parse(resultText);
        JsonElement page = Assert.Single(result.RootElement.GetProperty("pages").EnumerateArray());
        Assert.Equal("converted", page.GetProperty("status").GetString());

        string relativeMarkdownPath = Assert.Single(page.GetProperty("markdown_paths").EnumerateArray()).GetString()!;
        string markdownPath = System.IO.Path.Combine(
            workspace.Path,
            relativeMarkdownPath.Replace('/', System.IO.Path.DirectorySeparatorChar));
        byte[] markdownBytes = await File.ReadAllBytesAsync(markdownPath);
        string markdown = StrictDecode(markdownBytes);

        Assert.False(markdownBytes.AsSpan().StartsWith(Encoding.UTF8.Preamble));
        Assert.DoesNotContain('\r', markdown);
        Assert.Contains("Montréal", markdown, StringComparison.Ordinal);
        Assert.Contains("Validé", markdown, StringComparison.Ordinal);
        Assert.False(markdown.StartsWith("---", StringComparison.Ordinal));

        string attachmentDirectory = System.IO.Path.Combine(workspace.Path, "_attachments", "1001");
        Assert.True(File.Exists(System.IO.Path.Combine(attachmentDirectory, "architecture.drawio")));
        Assert.True(File.Exists(System.IO.Path.Combine(attachmentDirectory, "notes-café.txt")));
        string readableDrawIo = await File.ReadAllTextAsync(
            System.IO.Path.Combine(attachmentDirectory, "architecture.drawio.md"),
            Utf8WithoutBom);
        Assert.Contains("Décision validée", readableDrawIo, StringComparison.Ordinal);
        Assert.DoesNotContain('\r', readableDrawIo);
    }

    [Fact]
    public async Task PartialFailureFixtureReturnsTwoAndPreservesJobOrder()
    {
        using TestWorkspace workspace = TestWorkspace.FromFixture("partial-failure");

        int exitCode = await ConversionApplication.RunAsync(
            new[] { workspace.Path },
            CancellationToken.None);

        Assert.Equal(ConversionApplication.PartialFailureExitCode, exitCode);
        string resultPath = System.IO.Path.Combine(workspace.Path, "result.json");
        ValidateResult(resultPath);

        using JsonDocument result = JsonDocument.Parse(File.ReadAllText(resultPath));
        JsonElement.ArrayEnumerator pages = result.RootElement.GetProperty("pages").EnumerateArray();
        JsonElement[] orderedPages = pages.ToArray();
        Assert.Equal(new[] { "2001", "2002" }, orderedPages.Select(page => page.GetProperty("page_id").GetString()));
        Assert.Equal("converted", orderedPages[0].GetProperty("status").GetString());
        Assert.Equal("failed", orderedPages[1].GetProperty("status").GetString());
        Assert.Equal("xhtml_not_found", orderedPages[1].GetProperty("error_code").GetString());
    }

    [Fact]
    public void OutputNameResolverSuffixesCaseInsensitiveCollisions()
    {
        AttachmentJob first = new() { AttachmentId = "101", FileName = "Report.txt" };
        AttachmentJob second = new() { AttachmentId = "102", FileName = "report.txt" };

        bool resolved = ConversionApplication.TryResolveAttachmentOutputNames(
            new[] { first, second },
            out IReadOnlyDictionary<AttachmentJob, string> outputNames);

        Assert.True(resolved);
        Assert.Equal("Report-101.txt", outputNames[first]);
        Assert.Equal("report-102.txt", outputNames[second]);
    }

    [Fact]
    public void OutputNameResolverRejectsResidualCaseInsensitiveCollision()
    {
        AttachmentJob first = new() { AttachmentId = "101", FileName = "Report.txt" };
        AttachmentJob second = new() { AttachmentId = "101", FileName = "report.txt" };

        bool resolved = ConversionApplication.TryResolveAttachmentOutputNames(
            new[] { first, second },
            out IReadOnlyDictionary<AttachmentJob, string> outputNames);

        Assert.False(resolved);
        Assert.Empty(outputNames);
    }

    [Fact]
    public async Task AttachmentOutputSanitizationFixtureWritesDistinctFilesAndExactLinks()
    {
        using TestWorkspace workspace = TestWorkspace.FromFixture("attachment-output-sanitization");

        int exitCode = await ConversionApplication.RunAsync(
            new[] { workspace.Path },
            CancellationToken.None);

        Assert.Equal(ConversionApplication.SuccessExitCode, exitCode);
        string resultPath = System.IO.Path.Combine(workspace.Path, "result.json");
        ValidateResult(resultPath);

        string attachmentDirectory = System.IO.Path.Combine(workspace.Path, "_attachments", "574050555");
        const string sanitizedName = "Spreadsheet-2023-03-13T13_40_03-574050556.render";
        const string unchangedName = "Spreadsheet-2023-03-13T13-40-03.render";
        Assert.True(File.Exists(System.IO.Path.Combine(attachmentDirectory, sanitizedName)));
        Assert.True(File.Exists(System.IO.Path.Combine(attachmentDirectory, unchangedName)));

        using JsonDocument result = JsonDocument.Parse(await File.ReadAllTextAsync(resultPath));
        JsonElement page = Assert.Single(result.RootElement.GetProperty("pages").EnumerateArray());
        string relativeMarkdownPath = Assert.Single(page.GetProperty("markdown_paths").EnumerateArray()).GetString()!;
        string markdown = await File.ReadAllTextAsync(System.IO.Path.Combine(
            workspace.Path,
            relativeMarkdownPath.Replace('/', System.IO.Path.DirectorySeparatorChar)));

        Assert.Contains($"../_attachments/574050555/{sanitizedName}", markdown, StringComparison.Ordinal);
        Assert.Contains($"../_attachments/574050555/{unchangedName}", markdown, StringComparison.Ordinal);
        Assert.Contains("Spreadsheet-2023-03-13T13:40:03.render", markdown, StringComparison.Ordinal);
    }

    [Fact]
    public async Task TraversalPathReturnsOneWithoutWritingOutputs()
    {
        await AssertInvalidJobWritesNothingAsync(job =>
            job["pages"]![0]!["xhtml_path"] = "../outside.xhtml");
    }

    [Fact]
    public async Task DuplicatePageIdReturnsOneWithoutWritingOutputs()
    {
        await AssertInvalidJobWritesNothingAsync(job =>
        {
            JsonArray pages = job["pages"]!.AsArray();
            pages.Add(pages[0]!.DeepClone());
        });
    }

    [Fact]
    public async Task UnknownSchemaVersionReturnsOneWithoutWritingOutputs()
    {
        await AssertInvalidJobWritesNothingAsync(job => job["schema_version"] = 99);
    }

    [Fact]
    public async Task AbsolutePathReturnsOneWithoutWritingOutputs()
    {
        await AssertInvalidJobWritesNothingAsync(job =>
            job["pages"]![0]!["xhtml_path"] = "C:\\input\\page.xhtml");
    }

    private static async Task AssertInvalidJobWritesNothingAsync(Action<JsonNode> mutate)
    {
        using TestWorkspace workspace = TestWorkspace.FromFixture("nominal");
        string jobPath = System.IO.Path.Combine(workspace.Path, "job.json");
        JsonNode job = JsonNode.Parse(await File.ReadAllTextAsync(jobPath))!;
        mutate(job);
        await File.WriteAllTextAsync(jobPath, job.ToJsonString(new JsonSerializerOptions { WriteIndented = true }));
        string[] filesBefore = EnumerateRelativeFiles(workspace.Path);

        int exitCode = await ConversionApplication.RunAsync(
            new[] { workspace.Path },
            CancellationToken.None);

        Assert.Equal(ConversionApplication.GlobalFailureExitCode, exitCode);
        Assert.Equal(filesBefore, EnumerateRelativeFiles(workspace.Path));
        Assert.False(File.Exists(System.IO.Path.Combine(workspace.Path, "result.json")));
        Assert.False(Directory.Exists(System.IO.Path.Combine(workspace.Path, "markdown")));
        Assert.False(Directory.Exists(System.IO.Path.Combine(workspace.Path, "_attachments")));
    }

    private static void ValidateResult(string resultPath)
    {
        using JsonDocument result = JsonDocument.Parse(File.ReadAllText(resultPath));
        using JsonSchemaTestValidator validator = new(ContractPath("result.schema.json"));
        validator.Validate(result.RootElement);
    }

    private static string[] EnumerateRelativeFiles(string root)
    {
        return Directory.EnumerateFiles(root, "*", SearchOption.AllDirectories)
            .Select(path => System.IO.Path.GetRelativePath(root, path))
            .OrderBy(path => path, StringComparer.Ordinal)
            .ToArray();
    }

    private static string FixturePath(string fixtureName, params string[] segments)
    {
        return System.IO.Path.Combine(
            AppContext.BaseDirectory,
            "Fixtures",
            fixtureName,
            System.IO.Path.Combine(segments));
    }

    private static string ContractPath(string fileName)
    {
        return System.IO.Path.Combine(AppContext.BaseDirectory, "Contracts", fileName);
    }

    private static string StrictDecode(byte[] bytes)
    {
        return new UTF8Encoding(false, true).GetString(bytes);
    }

    private sealed class TestWorkspace : IDisposable
    {
        private TestWorkspace(string path)
        {
            Path = path;
        }

        internal string Path { get; }

        internal static TestWorkspace FromFixture(string fixtureName)
        {
            string source = FixturePath(fixtureName);
            string destination = System.IO.Path.Combine(
                System.IO.Path.GetTempPath(),
                "ConfluenceRAGBuilder.Console.Tests",
                Guid.NewGuid().ToString("N"));
            CopyDirectory(source, destination);
            return new TestWorkspace(destination);
        }

        public void Dispose()
        {
            if (Directory.Exists(Path))
            {
                Directory.Delete(Path, true);
            }
        }

        private static void CopyDirectory(string source, string destination)
        {
            Directory.CreateDirectory(destination);
            foreach (string directory in Directory.EnumerateDirectories(source, "*", SearchOption.AllDirectories))
            {
                Directory.CreateDirectory(System.IO.Path.Combine(
                    destination,
                    System.IO.Path.GetRelativePath(source, directory)));
            }

            foreach (string file in Directory.EnumerateFiles(source, "*", SearchOption.AllDirectories))
            {
                string target = System.IO.Path.Combine(destination, System.IO.Path.GetRelativePath(source, file));
                File.Copy(file, target);
            }
        }
    }
}
