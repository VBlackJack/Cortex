using ConfluenceRAGBuilder.Helpers;
using Xunit;

namespace ConfluenceRAGBuilder.Tests.Helpers;

public class DrawIoMacroHelperTests
{
    [Fact]
    public void ExtractDiagramNames_WithDrawIoMacro_ReturnsDiagramName()
    {
        var html = @"<ac:structured-macro ac:name=""drawio"">
                        <ac:parameter ac:name=""diagramName"">ADSEC - Architecture 2025</ac:parameter>
                      </ac:structured-macro>";

        var names = DrawIoMacroHelper.ExtractDiagramNames(html);

        Assert.Contains("ADSEC - Architecture 2025", names);
    }
}
