using ConfluenceRAGBuilder.Helpers;
using Xunit;

namespace ConfluenceRAGBuilder.Tests.Helpers;

public class FileNameHelperTests
{
    [Fact]
    public void ToSafeFileName_NormalName_ReturnsUnchanged()
    {
        var result = FileNameHelper.ToSafeFileName("my-document.pdf");
        Assert.Equal("my-document.pdf", result);
    }

    [Fact]
    public void ToSafeFileName_SpecialChars_ReplacesWithUnderscore()
    {
        var result = FileNameHelper.ToSafeFileName("guide:2026/report.pdf");
        Assert.DoesNotContain(":", result);
        Assert.DoesNotContain("/", result);
        Assert.Contains("_", result);
    }

    [Fact]
    public void ToSafeFileName_EmptyString_ReturnsFallback()
    {
        var result = FileNameHelper.ToSafeFileName("");
        Assert.Equal("file", result);
    }

    [Fact]
    public void ToSafeFileName_Null_ReturnsFallback()
    {
        var result = FileNameHelper.ToSafeFileName(null!);
        Assert.Equal("file", result);
    }

    [Fact]
    public void ToSafeFileName_AllInvalidChars_ReturnsFallback()
    {
        // Only invalid chars → becomes all underscores → not whitespace → returned
        var result = FileNameHelper.ToSafeFileName("<>:\"|?*");
        Assert.DoesNotContain("<", result);
        Assert.DoesNotContain(">", result);
    }

    [Fact]
    public void ToSafeFileName_CustomFallback_UsesProvidedFallback()
    {
        var result = FileNameHelper.ToSafeFileName("", "custom_fallback");
        Assert.Equal("custom_fallback", result);
    }

    [Fact]
    public void ToSafeFileName_WhitespaceOnly_ReturnsFallback()
    {
        var result = FileNameHelper.ToSafeFileName("   ");
        Assert.Equal("file", result);
    }

    [Fact]
    public void ToSafeFileName_Colon_ReplacesWithUnderscore()
    {
        var result = FileNameHelper.ToSafeFileName("Spreadsheet-2023-03-13T13:40:03.render");

        Assert.Equal("Spreadsheet-2023-03-13T13_40_03.render", result);
    }

    [Fact]
    public void ToSafeFileName_ReservedWindowsName_PrefixesUnderscore()
    {
        var result = FileNameHelper.ToSafeFileName("CON.txt");

        Assert.Equal("_CON.txt", result);
    }

    [Fact]
    public void ToSafeFileName_TrailingDot_RemovesDot()
    {
        var result = FileNameHelper.ToSafeFileName("rapport.");

        Assert.Equal("rapport", result);
    }

    [Fact]
    public void ToSafeFileName_OverMaximumLength_PreservesExtension()
    {
        var result = FileNameHelper.ToSafeFileName($"{new string('a', 300)}.render");

        Assert.Equal(FileNameHelper.MaximumWindowsFileNameLength, result.Length);
        Assert.EndsWith(".render", result, StringComparison.Ordinal);
    }
}
