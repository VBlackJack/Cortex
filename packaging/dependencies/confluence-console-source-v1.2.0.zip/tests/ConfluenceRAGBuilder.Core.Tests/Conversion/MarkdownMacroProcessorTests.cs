using ConfluenceRAGBuilder.Services.Conversion;
using ConfluenceRAGBuilder.Services.Conversion.MacroProcessors;
using HtmlAgilityPack;
using Xunit;

namespace ConfluenceRAGBuilder.Tests.Conversion;

public class MarkdownMacroProcessorTests
{
    private readonly MarkdownMacroProcessor _processor = new();

    [Fact]
    public void Process_WithCDataPlainTextBody_RendersMarkdown()
    {
        var html = @"<ac:structured-macro ac:name=""markdown"">
                        <ac:plain-text-body><![CDATA[## Title

- item]]></ac:plain-text-body>
                      </ac:structured-macro>";
        var doc = new HtmlDocument(); doc.LoadHtml(html);

        _processor.Process(doc.DocumentNode.FirstChild, new ConversionContext());

        Assert.Contains("<h2", doc.DocumentNode.OuterHtml);
        Assert.Contains("Title", doc.DocumentNode.InnerText);
        Assert.Contains("<li>item</li>", doc.DocumentNode.OuterHtml);
    }
}
