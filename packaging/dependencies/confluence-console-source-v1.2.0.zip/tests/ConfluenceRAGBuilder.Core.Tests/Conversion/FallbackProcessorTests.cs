// Author: Julien Bombled
// License: Apache 2.0

using ConfluenceRAGBuilder.Services.Conversion;
using ConfluenceRAGBuilder.Services.Conversion.MacroProcessors;
using HtmlAgilityPack;
using Xunit;

namespace ConfluenceRAGBuilder.Tests.Conversion;

public class FallbackProcessorTests
{
    private readonly FallbackProcessor _processor = new();

    [Fact]
    public void Process_UnknownMacro_ExtractsBodyAndAddsWarning()
    {
        var html = @"<ac:structured-macro ac:name=""unknown-macro"">
                        <ac:rich-text-body><p>Hidden text</p></ac:rich-text-body>
                      </ac:structured-macro>";
        var doc = new HtmlDocument(); doc.LoadHtml(html);
        var context = new ConversionContext();

        _processor.Process(doc.DocumentNode.FirstChild, context);

        Assert.Contains("<div><p>Hidden text</p></div>", doc.DocumentNode.OuterHtml);
        Assert.Single(context.Warnings);
        Assert.Equal("unknown-macro", context.Warnings[0].MacroName);
    }

    [Fact]
    public void Process_UnknownMacro_WithCDataPlainTextBody_ExtractsBodyAndAddsWarning()
    {
        var html = @"<ac:structured-macro ac:name=""unknown-macro"">
                        <ac:plain-text-body><![CDATA[---
key: value]]></ac:plain-text-body>
                      </ac:structured-macro>";
        var doc = new HtmlDocument(); doc.LoadHtml(html);
        var context = new ConversionContext();

        _processor.Process(doc.DocumentNode.FirstChild, context);

        Assert.Contains("---", doc.DocumentNode.InnerText);
        Assert.Contains("key: value", doc.DocumentNode.InnerText);
        Assert.Single(context.Warnings);
        Assert.Equal("unknown-macro", context.Warnings[0].MacroName);
    }
}
