// Author: Julien Bombled
// License: Apache 2.0

using ConfluenceRAGBuilder.Services.Conversion.MacroProcessors;
using Xunit;

namespace ConfluenceRAGBuilder.Tests.Conversion;

/// <summary>
/// Regression coverage for macros that fell through to FallbackProcessor on the CPDC export.
/// A macro name present in some processor's SupportedMacroNames means it is routed and no
/// "unsupported macro" warning is raised.
/// </summary>
public class ResidualMacroCoverageTests
{
    [Theory]
    [InlineData("table-chart")]
    [InlineData("table-joiner")]
    [InlineData("ui-image")]
    public void BodyMacroProcessor_Covers(string macro)
        => Assert.Contains(macro, new BodyMacroProcessor().SupportedMacroNames);

    [Theory]
    [InlineData("viewppt")]
    [InlineData("adhocboard")]
    public void DynamicContentProcessor_Covers(string macro)
        => Assert.Contains(macro, new DynamicContentProcessor().SupportedMacroNames);

    [Fact]
    public void JiraProcessor_CoversJiraChart()
        => Assert.Contains("jirachart", new JiraProcessor().SupportedMacroNames);
}
