using ConfluenceRAGBuilder.Services.Conversion;
using ConfluenceRAGBuilder.Services.Conversion.MacroProcessors;
using HtmlAgilityPack;
using Xunit;

namespace ConfluenceRAGBuilder.Tests.Conversion;

public class ViewFileProcessorTests
{
    private readonly ViewFileProcessor _processor = new();

    [Fact]
    public void Process_WithAttachment_CreatesAttachmentLink()
    {
        var html = @"<ac:structured-macro ac:name=""view-file"">
                        <ac:parameter ac:name=""name""><ri:attachment ri:filename=""guide:2026.pdf"" /></ac:parameter>
                      </ac:structured-macro>";
        var doc = new HtmlDocument(); doc.LoadHtml(html);
        var context = new ConversionContext { AttachmentsRelativePath = "_attachments/123/" };

        _processor.Process(doc.DocumentNode.FirstChild, context);

        Assert.Contains(@"href=""_attachments/123/guide_2026.pdf""", doc.DocumentNode.OuterHtml);
        Assert.Contains("guide:2026.pdf", doc.DocumentNode.InnerText);
    }
}
