using ConfluenceRAGBuilder.Services.Conversion;
using ConfluenceRAGBuilder.Services.Conversion.MacroProcessors;
using HtmlAgilityPack;
using Xunit;

namespace ConfluenceRAGBuilder.Tests.Conversion;

public class BodyMacroProcessorTests
{
    private readonly BodyMacroProcessor _processor = new();

    [Theory]
    [InlineData("section")]
    [InlineData("column")]
    [InlineData("ui-steps")]
    [InlineData("ui-step")]
    [InlineData("table-filter")]
    public void Process_BodyWrapperMacro_PreservesRichTextBody(string macroName)
    {
        var html = $@"<ac:structured-macro ac:name=""{macroName}"">
                        <ac:rich-text-body><p>Body content</p></ac:rich-text-body>
                      </ac:structured-macro>";
        var doc = new HtmlDocument(); doc.LoadHtml(html);

        _processor.Process(doc.DocumentNode.FirstChild, new ConversionContext());

        Assert.Contains("<div><p>Body content</p></div>", doc.DocumentNode.OuterHtml);
    }

    [Fact]
    public void Process_EasyHeadingMacro_CreatesHeading()
    {
        var html = @"<ac:structured-macro ac:name=""easy-heading-free"">
                        <ac:parameter ac:name=""title"">Operations</ac:parameter>
                      </ac:structured-macro>";
        var doc = new HtmlDocument(); doc.LoadHtml(html);

        _processor.Process(doc.DocumentNode.FirstChild, new ConversionContext());

        Assert.Contains("<h2>Operations</h2>", doc.DocumentNode.OuterHtml);
    }
}
