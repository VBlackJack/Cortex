// Author: Julien Bombled
// License: Apache 2.0

using System.Collections.Generic;
using ConfluenceRAGBuilder.Services.Conversion;
using ConfluenceRAGBuilder.Services.Conversion.MacroProcessors;
using Xunit;

namespace ConfluenceRAGBuilder.Tests.Conversion;

public class HtmlToMarkdownConverterTests
{
    private readonly HtmlToMarkdownConverter _converter;

    public HtmlToMarkdownConverterTests()
    {
        var processors = new List<IMacroProcessor>
        {
            new CodeBlockProcessor(),
            new PanelProcessor(),
            new ExpandProcessor(),
            new StatusProcessor(),
            new BodyMacroProcessor(),
            new LinkProcessor(),
            new ChildrenMacroProcessor(),
            new MarkdownMacroProcessor(),
            new ViewFileProcessor(),
            new DrawIoProcessor(),
            new FallbackProcessor()
        };
        _converter = new HtmlToMarkdownConverter(processors);
    }

    [Fact]
    public void Convert_HtmlWithCodeAndPanel_GeneratesMarkdown()
    {
        var html = @"
            <h1>Titre de page</h1>
            <ac:structured-macro ac:name=""info"">
              <ac:rich-text-body><p>Note importante</p></ac:rich-text-body>
            </ac:structured-macro>
            <p>Texte normal avec <ac:link><ri:url ri:value=""http://test.com""/><ac:plain-text-link-body>un lien</ac:plain-text-link-body></ac:link>.</p>
            <ac:structured-macro ac:name=""code"">
              <ac:parameter ac:name=""language"">csharp</ac:parameter>
              <ac:plain-text-body>var x = 1;</ac:plain-text-body>
            </ac:structured-macro>
        ";

        var result = _converter.Convert(html, new ConversionContext());

        Assert.Contains("# Titre de page", result.Markdown);
        Assert.Contains("> **ℹ️ INFO :**\n> Note importante", result.Markdown);
        Assert.Contains("Texte normal avec [un lien](http://test.com).", result.Markdown);
        Assert.Contains("```csharp\nvar x = 1;\n```", result.Markdown);
        Assert.True(result.HasCodeBlocks);
        Assert.True(result.WordCount > 0);
    }

    [Fact]
    public void Convert_UnknownMacro_UsesFallbackAndAddsWarning()
    {
        var html = @"<ac:structured-macro ac:name=""bizarre""><ac:plain-text-body>hello</ac:plain-text-body></ac:structured-macro>";
        var context = new ConversionContext();

        var result = _converter.Convert(html, context);

        Assert.Contains("hello", result.Markdown);
        Assert.Single(result.Warnings);
        Assert.Equal("bizarre", result.Warnings[0].MacroName);
    }

    [Fact]
    public void Convert_KnownMarketplaceMacros_DoesNotAddWarnings()
    {
        var html = @"
            <ac:structured-macro ac:name=""ui-children"" />
            <ac:structured-macro ac:name=""drawio"">
              <ac:parameter ac:name=""diagramName"">schema.drawio</ac:parameter>
            </ac:structured-macro>
            <ac:structured-macro ac:name=""section"">
              <ac:rich-text-body><p>Section content</p></ac:rich-text-body>
            </ac:structured-macro>
            <ac:structured-macro ac:name=""noformat"">
              <ac:plain-text-body><![CDATA[plain
text]]></ac:plain-text-body>
            </ac:structured-macro>
            <ac:structured-macro ac:name=""easy-dropdown-menu-status"">
              <ac:parameter ac:name=""text"">Ready</ac:parameter>
              <ac:parameter ac:name=""color"">Green</ac:parameter>
            </ac:structured-macro>
            <ac:structured-macro ac:name=""easy-heading-free"">
              <ac:parameter ac:name=""title"">Generated heading</ac:parameter>
            </ac:structured-macro>
            <ac:structured-macro ac:name=""table-filter"">
              <ac:rich-text-body><table><tbody><tr><td>A</td></tr></tbody></table></ac:rich-text-body>
            </ac:structured-macro>
            <ac:structured-macro ac:name=""ui-expand"">
              <ac:parameter ac:name=""title"">More</ac:parameter>
              <ac:rich-text-body><p>Expanded text</p></ac:rich-text-body>
            </ac:structured-macro>
            <ac:structured-macro ac:name=""details"">
              <ac:rich-text-body><p>Detail text</p></ac:rich-text-body>
            </ac:structured-macro>
            <ac:structured-macro ac:name=""unmigrated-wiki-markup"">
              <ac:plain-text-body><![CDATA[* old wiki markup]]></ac:plain-text-body>
            </ac:structured-macro>
            <ac:structured-macro ac:name=""ui-steps"">
              <ac:rich-text-body><p>Step one</p></ac:rich-text-body>
            </ac:structured-macro>";
        var context = new ConversionContext { AttachmentsRelativePath = "_attachments/123/" };

        var result = _converter.Convert(html, context);

        Assert.Empty(result.Warnings);
        Assert.Contains("[Sous-pages...]", result.Markdown);
        Assert.Contains("[schema.drawio](_attachments/123/schema.drawio)", result.Markdown);
        Assert.Contains("Section content", result.Markdown);
        Assert.Contains("plain\ntext", result.Markdown);
        Assert.Contains("[GREEN: Ready]", result.Markdown);
        Assert.Contains("Generated heading", result.Markdown);
        Assert.Contains("Expanded text", result.Markdown);
        Assert.Contains("Detail text", result.Markdown);
        Assert.Contains("old wiki markup", result.Markdown);
        Assert.Contains("Step one", result.Markdown);
    }
}
