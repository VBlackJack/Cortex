// Author: Julien Bombled
// License: Apache 2.0

using ConfluenceRAGBuilder.Services.Conversion;
using ConfluenceRAGBuilder.Services.Conversion.MacroProcessors;
using HtmlAgilityPack;
using Xunit;

namespace ConfluenceRAGBuilder.Tests.Conversion;

public class PanelProcessorTests
{
    private readonly PanelProcessor _processor = new();

    [Theory]
    [InlineData("info", "ℹ️", "INFO")]
    [InlineData("note", "📝", "NOTE")]
    [InlineData("warning", "⚠️", "WARNING")]
    [InlineData("tip", "💡", "TIP")]
    [InlineData("panel", "📋", "PANEL")]
    public void Process_KnownTypes_GeneratesCorrectHtml(string type, string expectedEmoji, string expectedLabel)
    {
        var html = $@"<ac:structured-macro ac:name=""{type}"">
                        <ac:rich-text-body><p>Content here</p></ac:rich-text-body>
                      </ac:structured-macro>";

        var doc = new HtmlDocument();
        doc.LoadHtml(html);
        var node = doc.DocumentNode.FirstChild;

        _processor.Process(node, new ConversionContext());

        var resultHtml = doc.DocumentNode.OuterHtml;
        Assert.Contains($"<blockquote><p><strong>{expectedEmoji} {expectedLabel} :</strong></p>", resultHtml);
        Assert.Contains("<p>Content here</p>", resultHtml);
    }

    [Fact]
    public void Process_WithCustomTitle_UsesTitle()
    {
        var html = @"<ac:structured-macro ac:name=""warning"">
                        <ac:parameter ac:name=""title"">Attention danger</ac:parameter>
                        <ac:rich-text-body><p>Content here</p></ac:rich-text-body>
                      </ac:structured-macro>";

        var doc = new HtmlDocument();
        doc.LoadHtml(html);
        var node = doc.DocumentNode.FirstChild;

        _processor.Process(node, new ConversionContext());

        var resultHtml = doc.DocumentNode.OuterHtml;
        Assert.Contains("<blockquote><p><strong>⚠️ Attention danger :</strong></p>", resultHtml);
    }
}
