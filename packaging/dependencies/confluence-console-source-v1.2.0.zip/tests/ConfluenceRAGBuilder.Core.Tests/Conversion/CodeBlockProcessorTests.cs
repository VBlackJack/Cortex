// Author: Julien Bombled
// License: Apache 2.0

using ConfluenceRAGBuilder.Services.Conversion;
using ConfluenceRAGBuilder.Services.Conversion.MacroProcessors;
using HtmlAgilityPack;
using Xunit;

namespace ConfluenceRAGBuilder.Tests.Conversion;

public class CodeBlockProcessorTests
{
    private readonly CodeBlockProcessor _processor = new();

    [Fact]
    public void Process_WithLanguageAndTitle_GeneratesCorrectHtml()
    {
        var html = @"<ac:structured-macro ac:name=""code"">
                       <ac:parameter ac:name=""language"">bash</ac:parameter>
                       <ac:parameter ac:name=""title"">Exemple</ac:parameter>
                       <ac:plain-text-body>echo ""hello""</ac:plain-text-body>
                     </ac:structured-macro>";

        var doc = new HtmlDocument();
        doc.LoadHtml(html);
        var node = doc.DocumentNode.FirstChild;

        _processor.Process(node, new ConversionContext());

        var resultHtml = doc.DocumentNode.OuterHtml;
        Assert.Contains("<em>📝 Exemple</em>", resultHtml);
        Assert.Contains("<code class=\"language-bash\">echo &quot;hello&quot;</code>", resultHtml);
    }

    [Fact]
    public void Process_WithoutParameters_GeneratesCorrectHtml()
    {
        var html = @"<ac:structured-macro ac:name=""code"">
                       <ac:plain-text-body>Console.WriteLine(""Test"");</ac:plain-text-body>
                     </ac:structured-macro>";

        var doc = new HtmlDocument();
        doc.LoadHtml(html);
        var node = doc.DocumentNode.FirstChild;

        _processor.Process(node, new ConversionContext());

        var resultHtml = doc.DocumentNode.OuterHtml;
        Assert.DoesNotContain("<em>📝", resultHtml);
        Assert.Contains("<code class=\"language-text\">Console.WriteLine(&quot;Test&quot;);</code>", resultHtml);
    }

    [Fact]
    public void Process_WithCDataPlainTextBody_PreservesCode()
    {
        var html = @"<ac:structured-macro ac:name=""code"">
                       <ac:parameter ac:name=""language"">yaml</ac:parameter>
                       <ac:parameter ac:name=""title"">.gitlab-ci.yml</ac:parameter>
                       <ac:plain-text-body><![CDATA[---
stages:
  - test

test_windows_vagrant:
  stage: test]]></ac:plain-text-body>
                     </ac:structured-macro>";

        var doc = new HtmlDocument();
        doc.LoadHtml(html);
        var node = doc.DocumentNode.FirstChild;

        _processor.Process(node, new ConversionContext());

        var resultHtml = doc.DocumentNode.OuterHtml;
        Assert.Contains("<em>📝 .gitlab-ci.yml</em>", resultHtml);
        Assert.Contains("stages:", resultHtml);
        Assert.Contains("test_windows_vagrant:", resultHtml);
    }

    [Fact]
    public void Process_NoformatMacro_PreservesPlainText()
    {
        var html = @"<ac:structured-macro ac:name=""noformat"">
                       <ac:plain-text-body><![CDATA[line 1
line 2]]></ac:plain-text-body>
                     </ac:structured-macro>";

        var doc = new HtmlDocument();
        doc.LoadHtml(html);

        _processor.Process(doc.DocumentNode.FirstChild, new ConversionContext());

        var resultHtml = doc.DocumentNode.OuterHtml;
        Assert.Contains("<code class=\"language-text\">line 1", resultHtml);
        Assert.Contains("line 2</code>", resultHtml);
    }
}
