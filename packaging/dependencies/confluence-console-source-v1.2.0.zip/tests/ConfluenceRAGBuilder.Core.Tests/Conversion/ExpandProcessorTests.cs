// Author: Julien Bombled
// License: Apache 2.0

using ConfluenceRAGBuilder.Services.Conversion;
using ConfluenceRAGBuilder.Services.Conversion.MacroProcessors;
using HtmlAgilityPack;
using Xunit;

namespace ConfluenceRAGBuilder.Tests.Conversion;

public class ExpandProcessorTests
{
    private readonly ExpandProcessor _processor = new();

    [Fact]
    public void Process_WithTitle_GeneratesDetails()
    {
        var html = @"<ac:structured-macro ac:name=""expand"">
                        <ac:parameter ac:name=""title"">Voir plus</ac:parameter>
                        <ac:rich-text-body><p>Contenu</p></ac:rich-text-body>
                      </ac:structured-macro>";
        var doc = new HtmlDocument(); doc.LoadHtml(html);
        _processor.Process(doc.DocumentNode.FirstChild, new ConversionContext());

        Assert.Contains("<details><summary>Voir plus</summary><div><p>Contenu</p></div></details>", doc.DocumentNode.OuterHtml);
    }

    [Theory]
    [InlineData("ui-expand")]
    [InlineData("details")]
    public void Process_SupportedExpandAliases_GeneratesDetails(string macroName)
    {
        var html = $@"<ac:structured-macro ac:name=""{macroName}"">
                        <ac:parameter ac:name=""title"">Voir plus</ac:parameter>
                        <ac:rich-text-body><p>Contenu</p></ac:rich-text-body>
                      </ac:structured-macro>";
        var doc = new HtmlDocument(); doc.LoadHtml(html);
        _processor.Process(doc.DocumentNode.FirstChild, new ConversionContext());

        Assert.Contains("<details><summary>Voir plus</summary>", doc.DocumentNode.OuterHtml);
        Assert.Contains("<p>Contenu</p>", doc.DocumentNode.OuterHtml);
    }
}
