using ConfluenceRAGBuilder.Services.Conversion;
using ConfluenceRAGBuilder.Services.Conversion.MacroProcessors;
using HtmlAgilityPack;
using Xunit;

namespace ConfluenceRAGBuilder.Tests.Conversion;

public class ChildrenMacroProcessorTests
{
    private readonly ChildrenMacroProcessor _processor = new();

    [Theory]
    [InlineData("children")]
    [InlineData("ui-children")]
    public void Process_ReplacesWithEmTag(string macroName)
    {
        var html = $@"<ac:structured-macro ac:name=""{macroName}""></ac:structured-macro>";

        var doc = new HtmlDocument();
        doc.LoadHtml(html);
        var node = doc.DocumentNode.FirstChild;

        _processor.Process(node, new ConversionContext());

        var resultHtml = doc.DocumentNode.OuterHtml;
        Assert.Contains("<em>", resultHtml);
        Assert.Contains("[Sous-pages...]", resultHtml);
    }
}
