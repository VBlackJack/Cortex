using System.Collections.Generic;
using ConfluenceRAGBuilder.Models;
using ConfluenceRAGBuilder.Services.Conversion;
using ConfluenceRAGBuilder.Services.Conversion.MacroProcessors;
using HtmlAgilityPack;
using Xunit;

namespace ConfluenceRAGBuilder.Tests.Conversion;

public class DrawIoProcessorTests
{
    private readonly DrawIoProcessor _processor = new();

    [Fact]
    public void Process_WithDiagramName_CreatesAttachmentLink()
    {
        var html = @"<ac:structured-macro ac:name=""drawio"">
                        <ac:parameter ac:name=""diagramName"">architecture</ac:parameter>
                      </ac:structured-macro>";
        var doc = new HtmlDocument(); doc.LoadHtml(html);
        var context = new ConversionContext
        {
            AttachmentsRelativePath = "_attachments/123/",
            Attachments = new List<AttachmentInfo>
            {
                new() { FileName = "architecture.drawio", DrawIoTextPath = @"C:\tmp\architecture.drawio.md" }
            }
        };

        _processor.Process(doc.DocumentNode.FirstChild, context);

        Assert.Contains(@"href=""_attachments/123/architecture.drawio.md""", doc.DocumentNode.OuterHtml);
        Assert.Contains("architecture", doc.DocumentNode.InnerText);
    }

    [Fact]
    public void Process_WithoutDiagramName_CreatesPlaceholder()
    {
        var html = @"<ac:structured-macro ac:name=""drawio"" />";
        var doc = new HtmlDocument(); doc.LoadHtml(html);

        _processor.Process(doc.DocumentNode.FirstChild, new ConversionContext());

        Assert.Contains("[Diagramme draw.io]", doc.DocumentNode.InnerText);
    }
}
