// Author: Julien Bombled
// License: Apache 2.0

using ConfluenceRAGBuilder.Services.Conversion;
using ConfluenceRAGBuilder.Services.Conversion.MacroProcessors;
using HtmlAgilityPack;
using Xunit;

namespace ConfluenceRAGBuilder.Tests.Conversion;

public class TaskListProcessorTests
{
    private readonly TaskListProcessor _processor = new();

    [Fact]
    public void Process_GeneratesCheckboxes()
    {
        var html = @"<ac:task-list>
                        <ac:task><ac:task-status>complete</ac:task-status><ac:task-body>T1</ac:task-body></ac:task>
                        <ac:task><ac:task-status>incomplete</ac:task-status><ac:task-body>T2</ac:task-body></ac:task>
                      </ac:task-list>";
        var doc = new HtmlDocument(); doc.LoadHtml(html);
        _processor.Process(doc.DocumentNode.FirstChild, new ConversionContext());

        var resultHtml = doc.DocumentNode.OuterHtml;
        Assert.Contains("<li>[x] <span>T1</span></li>", resultHtml);
        Assert.Contains("<li>[ ] <span>T2</span></li>", resultHtml);
    }
}
