// Author: Julien Bombled
// License: Apache 2.0

using ConfluenceRAGBuilder.Models;
using ConfluenceRAGBuilder.Services.Conversion;
using ConfluenceRAGBuilder.Services.Conversion.MacroProcessors;
using HtmlAgilityPack;
using Xunit;

namespace ConfluenceRAGBuilder.Tests.Conversion;

public class LinkProcessorTests
{
    private readonly LinkProcessor _processor = new();

    [Fact]
    public void Process_InternalPage_GeneratesAnchorLink()
    {
        var html = @"<ac:link><ri:page ri:content-title=""Install agent""/><ac:plain-text-link-body>voir installation</ac:plain-text-link-body></ac:link>";
        var doc = new HtmlDocument(); doc.LoadHtml(html);
        _processor.Process(doc.DocumentNode.FirstChild, new ConversionContext());
        Assert.Contains(@"<a href=""#Install-agent"">voir installation</a>", doc.DocumentNode.OuterHtml);
    }

    [Fact]
    public void Process_Attachment_GeneratesRelativeLink()
    {
        var html = @"<ac:link><ri:attachment ri:filename=""guide.pdf""/></ac:link>";
        var doc = new HtmlDocument(); doc.LoadHtml(html);

        var context = new ConversionContext { AttachmentsRelativePath = "_attachments/123/" };
        _processor.Process(doc.DocumentNode.FirstChild, context);

        Assert.Contains(@"<a href=""_attachments/123/guide.pdf"">guide.pdf</a>", doc.DocumentNode.OuterHtml);
    }

    [Fact]
    public void Process_Attachment_SanitizesRelativeLinkPath()
    {
        var html = @"<ac:link><ri:attachment ri:filename=""guide:2026.pdf""/></ac:link>";
        var doc = new HtmlDocument(); doc.LoadHtml(html);

        var context = new ConversionContext { AttachmentsRelativePath = "_attachments/123/" };
        _processor.Process(doc.DocumentNode.FirstChild, context);

        Assert.Contains(@"<a href=""_attachments/123/guide_2026.pdf"">guide:2026.pdf</a>", doc.DocumentNode.OuterHtml);
    }

    [Fact]
    public void Process_Attachment_MatchesOriginalNameAndLinksResolvedOutputName()
    {
        var html = @"<ac:link><ri:attachment ri:filename=""guide:2026.pdf""/></ac:link>";
        var doc = new HtmlDocument(); doc.LoadHtml(html);
        var context = new ConversionContext
        {
            AttachmentsRelativePath = "_attachments/123/",
            Attachments =
            [
                new AttachmentInfo
                {
                    FileName = "guide:2026.pdf",
                    OutputFileName = "guide_2026-att-42.pdf"
                }
            ]
        };

        _processor.Process(doc.DocumentNode.FirstChild, context);

        Assert.Contains(
            @"<a href=""_attachments/123/guide_2026-att-42.pdf"">guide:2026.pdf</a>",
            doc.DocumentNode.OuterHtml);
    }

    [Fact]
    public void Process_ExternalUrl_GeneratesHref()
    {
        var html = @"<ac:link><ri:url ri:value=""https://example.com""/><ac:plain-text-link-body>Go here</ac:plain-text-link-body></ac:link>";
        var doc = new HtmlDocument(); doc.LoadHtml(html);
        _processor.Process(doc.DocumentNode.FirstChild, new ConversionContext());
        Assert.Contains(@"<a href=""https://example.com"">Go here</a>", doc.DocumentNode.OuterHtml);
    }

    [Fact]
    public void Process_User_GeneratesMention()
    {
        var html = @"<ac:link><ri:user ri:userkey=""abc123""/></ac:link>";
        var doc = new HtmlDocument(); doc.LoadHtml(html);
        _processor.Process(doc.DocumentNode.FirstChild, new ConversionContext());
        Assert.Contains(@"<span>@abc123</span>", doc.DocumentNode.OuterHtml);
    }
}
