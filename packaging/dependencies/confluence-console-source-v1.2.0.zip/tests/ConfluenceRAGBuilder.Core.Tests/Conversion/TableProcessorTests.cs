using ConfluenceRAGBuilder.Services.Conversion;
using ConfluenceRAGBuilder.Services.Conversion.MacroProcessors;
using HtmlAgilityPack;
using Xunit;

namespace ConfluenceRAGBuilder.Tests.Conversion;

public class TableProcessorTests
{
    private readonly TableProcessor _processor = new();

    [Fact]
    public void Process_ThRowInTbody_MovesToThead()
    {
        var html = @"<table>
            <tbody>
                <tr><th>Header 1</th><th>Header 2</th></tr>
                <tr><td>Data 1</td><td>Data 2</td></tr>
            </tbody>
        </table>";

        var doc = new HtmlDocument();
        doc.LoadHtml(html);
        var node = doc.DocumentNode.SelectSingleNode("//table");

        _processor.Process(node, new ConversionContext());

        var resultHtml = doc.DocumentNode.OuterHtml;
        Assert.Contains("<thead>", resultHtml);
        Assert.Contains("Header 1", resultHtml);
        // Data row should still be in tbody
        Assert.Contains("Data 1", resultHtml);
    }

    [Fact]
    public void Process_NoThInFirstRow_DoesNotCreateThead()
    {
        var html = @"<table>
            <tbody>
                <tr><td>Data 1</td><td>Data 2</td></tr>
            </tbody>
        </table>";

        var doc = new HtmlDocument();
        doc.LoadHtml(html);
        var node = doc.DocumentNode.SelectSingleNode("//table");

        _processor.Process(node, new ConversionContext());

        var resultHtml = doc.DocumentNode.OuterHtml;
        Assert.DoesNotContain("<thead>", resultHtml);
    }

    [Fact]
    public void Process_TableWithoutTbody_NoException()
    {
        var html = @"<table><tr><td>Cell</td></tr></table>";

        var doc = new HtmlDocument();
        doc.LoadHtml(html);
        var node = doc.DocumentNode.SelectSingleNode("//table");

        _processor.Process(node, new ConversionContext());

        Assert.Contains("Cell", doc.DocumentNode.OuterHtml);
    }
}
