using System.Linq;
using ConfluenceRAGBuilder.Services.Conversion;
using ConfluenceRAGBuilder.Services.Conversion.MacroProcessors;
using HtmlAgilityPack;
using Xunit;

namespace ConfluenceRAGBuilder.Tests.Conversion;

public class TocProcessorTests
{
    private readonly TocProcessor _processor = new();

    [Fact]
    public void Process_RemovesTocMacroNode()
    {
        var html = @"<div><ac:structured-macro ac:name=""toc""></ac:structured-macro><p>Content after TOC</p></div>";

        var doc = new HtmlDocument();
        doc.LoadHtml(html);
        var node = doc.DocumentNode.Descendants("ac:structured-macro").First();

        _processor.Process(node, new ConversionContext());

        var resultHtml = doc.DocumentNode.OuterHtml;
        Assert.DoesNotContain("ac:structured-macro", resultHtml);
        Assert.Contains("Content after TOC", resultHtml);
    }
}
