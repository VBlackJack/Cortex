// Author: Julien Bombled
// License: Apache 2.0

using ConfluenceRAGBuilder.Services.Conversion;
using ConfluenceRAGBuilder.Services.Conversion.MacroProcessors;
using HtmlAgilityPack;
using Xunit;

namespace ConfluenceRAGBuilder.Tests.Conversion;

public class StatusProcessorTests
{
    private readonly StatusProcessor _processor = new();

    [Fact]
    public void Process_GeneratesStatusLabel()
    {
        var html = @"<ac:structured-macro ac:name=""status"">
                        <ac:parameter ac:name=""title"">DONE</ac:parameter>
                        <ac:parameter ac:name=""colour"">Green</ac:parameter>
                      </ac:structured-macro>";
        var doc = new HtmlDocument(); doc.LoadHtml(html);
        _processor.Process(doc.DocumentNode.FirstChild, new ConversionContext());

        Assert.Contains("<code>[GREEN: DONE]</code>", doc.DocumentNode.OuterHtml);
    }

    [Fact]
    public void Process_EasyDropdownStatus_GeneratesStatusLabel()
    {
        var html = @"<ac:structured-macro ac:name=""easy-dropdown-menu-status"">
                        <ac:parameter ac:name=""text"">In progress</ac:parameter>
                        <ac:parameter ac:name=""color"">Blue</ac:parameter>
                      </ac:structured-macro>";
        var doc = new HtmlDocument(); doc.LoadHtml(html);
        _processor.Process(doc.DocumentNode.FirstChild, new ConversionContext());

        Assert.Contains("<code>[BLUE: In progress]</code>", doc.DocumentNode.OuterHtml);
    }
}
