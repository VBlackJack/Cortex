// Author: Julien Bombled
// License: Apache 2.0

using ConfluenceRAGBuilder.Services.Conversion;
using ConfluenceRAGBuilder.Services.Conversion.MacroProcessors;
using HtmlAgilityPack;
using Xunit;

namespace ConfluenceRAGBuilder.Tests.Conversion;

public class EmoticonProcessorTests
{
    private readonly EmoticonProcessor _processor = new();

    [Fact]
    public void Process_KnownEmoticon_GeneratesEmoji()
    {
        var html = @"<ac:emoticon ac:name=""warning""/>";
        var doc = new HtmlDocument(); doc.LoadHtml(html);
        _processor.Process(doc.DocumentNode.FirstChild, new ConversionContext());

        Assert.Contains("<span>⚠️</span>", doc.DocumentNode.OuterHtml);
    }
}
