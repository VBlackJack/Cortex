// Author: Julien Bombled
// License: Apache 2.0

using ConfluenceRAGBuilder.Services.Conversion;
using ConfluenceRAGBuilder.Services.Conversion.MacroProcessors;
using HtmlAgilityPack;
using Xunit;

namespace ConfluenceRAGBuilder.Tests.Conversion;

public class ImageProcessorTests
{
    private readonly ImageProcessor _processor = new();

    [Fact]
    public void Process_Attachment_GeneratesRelativeImg()
    {
        var html = @"<ac:image><ri:attachment ri:filename=""test.png""/></ac:image>";
        var doc = new HtmlDocument(); doc.LoadHtml(html);
        var context = new ConversionContext { AttachmentsRelativePath = "_attachments/123/" };
        _processor.Process(doc.DocumentNode.FirstChild, context);

        Assert.Contains(@"<img src=""_attachments/123/test.png"" alt=""test.png"">", doc.DocumentNode.OuterHtml);
    }

    [Fact]
    public void Process_Attachment_SanitizesRelativeImgPath()
    {
        var html = @"<ac:image><ri:attachment ri:filename=""report:2026.png""/></ac:image>";
        var doc = new HtmlDocument(); doc.LoadHtml(html);
        var context = new ConversionContext { AttachmentsRelativePath = "_attachments/123/" };
        _processor.Process(doc.DocumentNode.FirstChild, context);

        Assert.Contains(@"<img src=""_attachments/123/report_2026.png"" alt=""report:2026.png"">", doc.DocumentNode.OuterHtml);
    }

    [Fact]
    public void Process_ExternalUrl_GeneratesHrefImg()
    {
        var html = @"<ac:image><ri:url ri:value=""https://example.com/a.png""/></ac:image>";
        var doc = new HtmlDocument(); doc.LoadHtml(html);
        _processor.Process(doc.DocumentNode.FirstChild, new ConversionContext());

        var expected = @"<img src=""https://example.com/a.png"" alt=""image"">";
        Assert.Contains(expected, doc.DocumentNode.OuterHtml);
    }
}
