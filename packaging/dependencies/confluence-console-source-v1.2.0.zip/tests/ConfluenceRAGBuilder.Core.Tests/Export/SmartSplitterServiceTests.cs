using ConfluenceRAGBuilder.Models;
using ConfluenceRAGBuilder.Services.Export;
using Xunit;

namespace ConfluenceRAGBuilder.Tests.Export
{
    public class SmartSplitterServiceTests
    {
        private readonly SmartSplitterService _service;

        public SmartSplitterServiceTests()
        {
            _service = new SmartSplitterService();
        }

        [Fact]
        public void Split_WhenWordCountBelowThreshold_ShouldNotSplit()
        {
            var markdown = "This is a short text with only a few words.";
            var options = new SplitOptions { ThresholdWordCount = 2000 };

            var result = _service.Split(markdown, "base", "Page Title", options);

            Assert.False(result.IsSplit);
            Assert.Single(result.Parts);
            Assert.Equal("base.md", result.Parts[0].FileName);
            Assert.True(result.Parts[0].IsParent);
        }

        [Fact]
        public void Split_WhenNoH2_ShouldNotSplit()
        {
            var sb = new System.Text.StringBuilder();
            for (int i = 0; i < 50; i++) sb.Append("word ");
            var markdown = sb.ToString();

            var options = new SplitOptions { ThresholdWordCount = 20 };

            var result = _service.Split(markdown, "base", "Page Title", options);

            Assert.False(result.IsSplit);
        }

        [Fact]
        public void Split_WhenValidH2sAndAboveThreshold_ShouldSplit()
        {
            var markdown = @"Intro text that goes here.
## Section 1
Content for section 1.
## Section 2
Content for section 2.";

            var longText = "word ".PadRight(100, 'a').Replace("a", "word ");
            markdown = markdown.Replace("Content for section 1.", "Content for section 1. " + longText);
            markdown = markdown.Replace("Content for section 2.", "Content for section 2. " + longText);

            var options = new SplitOptions { ThresholdWordCount = 10, MinSectionWordCount = 5 };

            var result = _service.Split(markdown, "base", "Page Title", options);

            Assert.True(result.IsSplit);
            Assert.Equal(3, result.Parts.Count);

            var parent = result.Parts[0];
            Assert.True(parent.IsParent);
            Assert.Contains("## Table of Contents", parent.Content);
            Assert.Contains("[Section 1](./basea__section-1.md)", parent.Content);

            var child1 = result.Parts[1];
            Assert.False(child1.IsParent);
            Assert.Equal("basea__section-1.md", child1.FileName);
            Assert.Contains("## Section 1", child1.Content);

            var child2 = result.Parts[2];
            Assert.Equal("baseb__section-2.md", child2.FileName);
        }

        [Fact]
        public void Split_WhenSectionBelowMinWordCount_ShouldMerge()
        {
            var markdown = @"Intro
## Section 1
Lots of words here. Lots of words here. Lots of words here. Lots of words here. Lots of words here.
## Section 2
Few words.
## Section 3
More words here to make it above minimum threshold hopefully. Extra words. Extra words.";

            var options = new SplitOptions { ThresholdWordCount = 5, MinSectionWordCount = 10 };

            var result = _service.Split(markdown, "base", "Page Title", options);

            Assert.True(result.IsSplit);
            Assert.Equal(3, result.Parts.Count);

            var child2 = result.Parts[2];
            Assert.Contains("## Section 2", child2.Content);
            Assert.Contains("## Section 3", child2.Content);
        }
    }
}
