using System.IO;
using System.IO.Compression;
using System.Text;
using System.Threading.Tasks;
using ConfluenceRAGBuilder.Models;
using ConfluenceRAGBuilder.Services.Export;
using Xunit;

namespace ConfluenceRAGBuilder.Tests.Export;

public class DrawIoTextExporterTests
{
    [Fact]
    public void BuildReadableMarkdown_UncompressedDrawIo_ExtractsLabelsAndXml()
    {
        const string drawIo = @"<mxfile>
  <diagram name=""Main"">
    <mxGraphModel>
      <root>
        <mxCell id=""1"" value=""Start &lt;br&gt; deploy"" vertex=""1"" />
        <mxCell id=""2"" value=""Server"" vertex=""1"" />
      </root>
    </mxGraphModel>
  </diagram>
</mxfile>";

        var markdown = DrawIoTextExporter.BuildReadableMarkdown("schema.drawio", drawIo);

        Assert.Contains("# Diagramme draw.io - schema.drawio", markdown);
        Assert.Contains("## Main", markdown);
        Assert.Contains("- Start deploy", markdown);
        Assert.Contains("- Server", markdown);
        Assert.Contains("<mxGraphModel>", markdown);
    }

    [Fact]
    public async Task ExportReadableMarkdownAsync_DrawIoFile_WritesMarkdownSidecar()
    {
        var targetDirectory = Path.Combine(Path.GetTempPath(), "ConfluenceRAGBuilderTests", System.Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(targetDirectory);
        var drawIoPath = Path.Combine(targetDirectory, "schema.drawio");
        await File.WriteAllTextAsync(drawIoPath, @"<mxfile><diagram name=""Main""><mxGraphModel><root><mxCell id=""1"" value=""Service A"" /></root></mxGraphModel></diagram></mxfile>");

        var attachment = new AttachmentInfo
        {
            FileName = "schema.drawio",
            LocalPath = drawIoPath
        };

        try
        {
            var markdownPath = await DrawIoTextExporter.ExportReadableMarkdownAsync(attachment);

            Assert.Equal(Path.Combine(targetDirectory, "schema.drawio.md"), markdownPath);
            Assert.Equal(markdownPath, attachment.DrawIoTextPath);
            Assert.True(File.Exists(markdownPath));
            Assert.Contains("Service A", await File.ReadAllTextAsync(markdownPath!));
        }
        finally
        {
            Directory.Delete(targetDirectory, true);
        }
    }

    [Fact]
    public async Task ExportReadableMarkdownAsync_ExplicitDrawIoSourceWithoutExtension_WritesMarkdownSidecar()
    {
        var targetDirectory = Path.Combine(Path.GetTempPath(), "ConfluenceRAGBuilderTests", System.Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(targetDirectory);
        var sourcePath = Path.Combine(targetDirectory, "schema");
        await File.WriteAllTextAsync(sourcePath, @"<mxfile><diagram name=""Main""><mxGraphModel><root><mxCell id=""1"" value=""Service A"" /></root></mxGraphModel></diagram></mxfile>");

        var attachment = new AttachmentInfo
        {
            FileName = "schema",
            LocalPath = sourcePath,
            IsDrawIoSourceCandidate = true
        };

        try
        {
            var markdownPath = await DrawIoTextExporter.ExportReadableMarkdownAsync(attachment);

            Assert.Equal(Path.Combine(targetDirectory, "schema.md"), markdownPath);
            Assert.Equal(markdownPath, attachment.DrawIoTextPath);
            Assert.True(File.Exists(markdownPath));
            Assert.Contains("Service A", await File.ReadAllTextAsync(markdownPath!));
        }
        finally
        {
            Directory.Delete(targetDirectory, true);
        }
    }

    [Fact]
    public async Task ExportReadableMarkdownAsync_PngWithEmbeddedDrawIoMetadata_WritesMarkdownSidecar()
    {
        var targetDirectory = Path.Combine(Path.GetTempPath(), "ConfluenceRAGBuilderTests", System.Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(targetDirectory);
        var pngPath = Path.Combine(targetDirectory, "schema.png");
        await File.WriteAllBytesAsync(pngPath, CreatePngWithZtxtMxfile(@"<mxfile><diagram name=""Main""><mxGraphModel><root><mxCell id=""1"" value=""Service A"" /></root></mxGraphModel></diagram></mxfile>"));

        var attachment = new AttachmentInfo
        {
            FileName = "schema.png",
            LocalPath = pngPath
        };

        try
        {
            var markdownPath = await DrawIoTextExporter.ExportReadableMarkdownAsync(attachment);

            Assert.Equal(Path.Combine(targetDirectory, "schema.png.md"), markdownPath);
            Assert.Equal(markdownPath, attachment.DrawIoTextPath);
            Assert.True(File.Exists(markdownPath));
            Assert.Contains("Service A", await File.ReadAllTextAsync(markdownPath!));
        }
        finally
        {
            Directory.Delete(targetDirectory, true);
        }
    }

    [Fact]
    public async Task ExportReadableMarkdownAsync_PngWithoutDrawIoMetadata_ReturnsNull()
    {
        var targetDirectory = Path.Combine(Path.GetTempPath(), "ConfluenceRAGBuilderTests", System.Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(targetDirectory);
        var pngPath = Path.Combine(targetDirectory, "screenshot.png");
        await File.WriteAllBytesAsync(pngPath, CreatePngWithText("Comment", "plain screenshot"));

        var attachment = new AttachmentInfo
        {
            FileName = "screenshot.png",
            LocalPath = pngPath
        };

        try
        {
            var markdownPath = await DrawIoTextExporter.ExportReadableMarkdownAsync(attachment);

            Assert.Null(markdownPath);
            Assert.Equal(string.Empty, attachment.DrawIoTextPath);
        }
        finally
        {
            Directory.Delete(targetDirectory, true);
        }
    }

    private static byte[] CreatePngWithZtxtMxfile(string mxfileXml)
    {
        using var compressedStream = new MemoryStream();
        using (var zlib = new ZLibStream(compressedStream, CompressionLevel.SmallestSize, leaveOpen: true))
        {
            zlib.Write(Encoding.UTF8.GetBytes(mxfileXml));
        }

        var keyword = Encoding.UTF8.GetBytes("mxfile");
        var data = keyword
            .Concat(new byte[] { 0, 0 })
            .Concat(compressedStream.ToArray())
            .ToArray();

        return CreatePngWithChunk("zTXt", data);
    }

    private static byte[] CreatePngWithText(string keyword, string text)
    {
        var data = Encoding.UTF8.GetBytes(keyword)
            .Concat(new byte[] { 0 })
            .Concat(Encoding.UTF8.GetBytes(text))
            .ToArray();

        return CreatePngWithChunk("tEXt", data);
    }

    private static byte[] CreatePngWithChunk(string chunkType, byte[] chunkData)
    {
        using var png = new MemoryStream();
        png.Write(new byte[] { 137, 80, 78, 71, 13, 10, 26, 10 });
        WritePngChunk(png, chunkType, chunkData);
        WritePngChunk(png, "IEND", System.Array.Empty<byte>());
        return png.ToArray();
    }

    private static void WritePngChunk(Stream stream, string chunkType, byte[] data)
    {
        var lengthBytes = System.BitConverter.GetBytes(System.Net.IPAddress.HostToNetworkOrder(data.Length));
        stream.Write(lengthBytes);
        stream.Write(Encoding.ASCII.GetBytes(chunkType));
        stream.Write(data);
        stream.Write(new byte[4]); // CRC is not validated by the exporter.
    }
}
